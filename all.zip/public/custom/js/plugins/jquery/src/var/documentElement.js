define( [
	"./document"
], function( document ) {
	"use strict";

	return document.documentElement;
} );
