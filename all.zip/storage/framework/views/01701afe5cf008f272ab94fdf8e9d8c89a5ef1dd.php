
<?php $__env->startSection('title', __('cow_vaccine_monitor.cow_vaccine_monitor')); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="fa fa-eyedropper"></i> <?php echo e(__('cow_vaccine_monitor.cow_vaccine_monitor')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
	<li class="active"><?php echo e(__('cow_vaccine_monitor.cow_vaccine_monitor')); ?></li>
  </ol>
</section>
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('common.commonFunction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success"> <?php if(empty($single_data)): ?>
    <?php echo e(Form::open(array('route' => 'vaccine-monitor.store', 'method' => 'post', 'files' => true))); ?>

    <?php $btn_name = __('same.save'); ?>
    <?php else: ?>
    <?php echo e(Form::open(array('route' => ['vaccine-monitor.update',$single_data->id], 'method' => 'PUT', 'files' => true))); ?>

    <?php $btn_name = __('same.update'); ?>
    <?php endif; ?>
    <div class="box-header with-border" align="right">
      <button type="submit" class="btn btn-success btn-sm"><i class="fa fa-floppy-o"></i> <b><?php echo e($btn_name); ?> <?php echo e(__('same.information')); ?></b></button>
      <a href="<?php echo e(url('vaccine-monitor/create')); ?>" class="btn btn-warning btn-sm"><i class="fa fa-refresh"></i> <b> <?php echo e(__('same.refresh')); ?></b></a> &nbsp;&nbsp; </div>
    <div class="box-body">
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading feed-heading"><i class="fa fa-info-circle"></i>&nbsp;<?php echo e(__('cow_vaccine_monitor.animal_information')); ?> :</div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-12">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="shed_no"><?php echo e(__('cow_vaccine_monitor.stall_no')); ?> <span class="validate">*</span> : </label>
                    <select class="form-control load-cow-vacine-page" name="shed_no" id="shed_no" data-url="<?php echo e(URL::to('load-cow')); ?>" required>
                      <option value=""><?php echo e(__('same.select')); ?></option>
						<?php $__currentLoopData = $all_sheds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sheds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      		<option value="<?php echo e($sheds->id); ?>" <?php echo e((!empty($single_data))?($sheds->id==$single_data->shed_no)?'selected':'':''); ?>><?php echo e($sheds->shed_number); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="cow_id"><?php echo e(__('cow_vaccine_monitor.cow_no')); ?> <span class="validate">*</span> : </label>
                    <select class="form-control animal-details-by-stall-no" name="cow_id" id="cow_id" data-url="<?php echo e(URL::to('animal-details')); ?>" required>
                      <option value=""><?php echo e(__('same.select')); ?></option>
						<?php if(isset($single_data)): ?>
							<?php $__currentLoopData = $cowArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cowArrData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  							<option value="<?php echo e($cowArrData->id); ?>" <?php echo e(($cowArrData->id==$single_data->cow_id)?'selected':''); ?>>000<?php echo e($cowArrData->id); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-12" id="animal-details" align="center"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading feed-heading"><i class="fa fa-edit"></i>&nbsp;<?php echo e(__('cow_vaccine_monitor.vaccine_date_note')); ?> :</div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-12">
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="date"><?php echo e(__('cow_vaccine_monitor.date')); ?> <span class="validate">*</span> : </label>
                    <input type="text" name="date" class="form-control wsit_datepicker" value="<?php echo e((!empty($single_data->date))?date('m/d/Y', strtotime($single_data->date)):''); ?>" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="note"><?php echo e(__('cow_vaccine_monitor.note')); ?> : </label>
                    <textarea name="note" class="form-control"><?php echo e((!empty($single_data->note))?$single_data->note:''); ?></textarea>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading feed-heading"><i class="icon-list"></i>&nbsp;<?php echo e(__('cow_vaccine_monitor.vaccines_list')); ?> :</div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-12">
                <table class="table table-responsive table-bordered table-striped">
                  	<th><?php echo e(__('cow_vaccine_monitor.vaccine_name')); ?></th>
                    <th><?php echo e(__('cow_vaccine_monitor.dose')); ?></th>
                    <th><?php echo e(__('cow_vaccine_monitor.repeat')); ?></th>
                    <th><?php echo e(__('cow_vaccine_monitor.remarks')); ?></th>
                    <th><?php echo e(__('cow_vaccine_monitor.given_time')); ?></th>
                  <tbody>
                    <?php $row = 1; ?>
                  <?php $__currentLoopData = $vaccine_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaccine_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(isset($single_data)): ?>
                  <?php  
						$checkData = DB::table('cow_vaccine_monitor_dtls')
									 ->where('monitor_id', $single_data->id)
									 ->where('vaccine_id', $vaccine_data->id)
									 ->exists();
						if($checkData==true){
							$savedData = DB::table('cow_vaccine_monitor_dtls')
									 ->where('monitor_id', $single_data->id)
									 ->where('vaccine_id', $vaccine_data->id)
									 ->first();
						}
					?>
                  <?php endif; ?>
                  <tr>
                    <td><label class="checkbox-inline">
                      <input class="cow-veccine" id="veccine_<?php echo e($vaccine_data->id); ?>" type="checkbox" name="cow_vaccine[<?php echo e($row); ?>][vaccine_id]" value="<?php echo e($vaccine_data->id); ?>" <?php echo e((isset($checkData)?($checkData==true)?'checked':'':'')); ?>>
                      <?php echo e($vaccine_data->vaccine_name); ?> - ( <?php echo e($vaccine_data->months); ?> <?php echo e(__('cow_vaccine_monitor.days')); ?> ) </label>
                    </td>
                    <td> <?php echo e($vaccine_data->dose); ?> </td>
                    <td align="center"><?php if((bool)$vaccine_data->repeat_vaccine): ?><i class="fa fa-check"></i><?php else: ?><i class="fa fa-close"></i><?php endif; ?></td>
                    <td><input type="text" name="cow_vaccine[<?php echo e($row); ?>][remarks]" class="form-control" value="<?php echo e((isset($checkData)?($checkData==true)?$savedData->remarks:'':'')); ?>">
                    </td>
                    <td><input type="text" name="cow_vaccine[<?php echo e($row); ?>][time]" class="form-control" value="<?php echo e((isset($checkData)?($checkData==true)?$savedData->time:'':'')); ?>">
                    </td>
                  </tr>
                  <?php $row++; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php echo Form::close(); ?> </div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vflhvhga/hadirinn/resources/views/cow-vaccine-monitor/form.blade.php ENDPATH**/ ?>