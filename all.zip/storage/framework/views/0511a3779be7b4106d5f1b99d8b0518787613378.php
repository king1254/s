<?php $__env->startSection('title', __('invoice.title')); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1><i class="icon-docs"></i> <?php echo e(__('invoice.title')); ?></h1>
  <ol class="breadcrumb">
    <li><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></li>
    <li class="active"><?php echo e(__('same.invoice')); ?></li>
  </ol>
</section>
<?php 
$configuration_data = \App\Library\farm::get_system_configuration('system_config'); 
$branchFullData = DB::table('branchs')->where('id', Session::get('branch_id'))->first();
?>
<section class="content"> <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="<?php echo e(URL::to('sale-cow')); ?>" class="btn btn-default btn-sm"><i class="icon-list"></i> <?php echo e(__('same.back')); ?></a> <a href="javascript:;" class="btn btn-default btn-sm printReport"><i class="icon-printer"></i> <?php echo e(__('same.print')); ?></a> </div>
    <div class="box-body">
      <div class="container" id="print-box">
        <div class="card">
          <div class="card-header"> Invoice <strong> #000<?php echo e($single_data->id); ?></strong> <span class="float-right"> <strong>Issue Date:</strong> <?php echo e(Carbon\Carbon::parse($single_data->date)->format('d/m/Y')); ?></span> </div>
          <div class="card-body">
            <div class="row mb-4">
              <div class="col-sm-8">
                <h6 class="mb-3"><?php echo e(__('invoice.from')); ?>:</h6>
                <div> <strong><?php if(!empty($configuration_data) && !empty($configuration_data->topTitle)): ?><?php echo e($configuration_data->topTitle); ?><?php endif; ?></strong> </div>
                <div><?php if(!empty($branchFullData->branch_name)): ?><?php echo e($branchFullData->branch_name); ?><?php endif; ?></div>
                <div><?php if(!empty($branchFullData->branch_address)): ?><?php echo e($branchFullData->branch_address); ?><?php endif; ?></div>
                <div><?php echo e(__('invoice.email')); ?>: <?php if(!empty($branchFullData->phone_number)): ?><?php echo e($branchFullData->phone_number); ?><?php endif; ?></div>
                <div><?php echo e(__('invoice.phone')); ?>: <?php if(!empty($branchFullData->email)): ?><?php echo e($branchFullData->email); ?><?php endif; ?></div>
              </div>
              <div class="col-sm-4">
                <h6 class="mb-3"><?php echo e(__('invoice.to')); ?>:</h6>
                <div> <strong><?php if(!empty($single_data) && !empty($single_data->customer_name)): ?><?php echo e($single_data->customer_name); ?><?php endif; ?></strong> </div>
                <div><?php echo e(__('invoice.phone')); ?>: <?php if(!empty($single_data) && !empty($single_data->customer_number)): ?><?php echo e($single_data->customer_number); ?><?php endif; ?></div>
                <div><?php echo e(__('invoice.email')); ?>: <?php if(!empty($single_data) && !empty($single_data->email)): ?><?php echo e($single_data->email); ?><?php endif; ?></div>
                <div><?php echo e(__('invoice.address')); ?>: <?php if(!empty($single_data) && !empty($single_data->address)): ?><?php echo e($single_data->address); ?><?php endif; ?></div>
              </div>
            </div>
            <div class="table-responsive-sm table_scroll">
              <table class="table table-striped invoice_table">
                <thead>
                  <tr>
                    <th class="center">#</th>
                    <th><?php echo e(__('invoice.item')); ?></th>
                    <th><?php echo e(__('invoice.description')); ?></th>
                    <th><?php echo e(__('invoice.price')); ?></th>
                    <th class="right"><?php echo e(__('invoice.total')); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $cowInfo = DB::table('cow_sale_dtls')->where('sale_id', $single_data->id)->get(); ?>
                  <?php if(!empty($cowInfo)) { ?>
                <?php $__currentLoopData = $cowInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cowInfoData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php  
									  if($cowInfoData->cow_type==1) {
                                        $dataInfo = DB::table('animals')
										->leftJoin('sheds', 'sheds.id', 'animals.shade_no')
										->leftJoin('animal_type', 'animal_type.id', 'animals.animal_type')
                                        ->where('animals.id', $cowInfoData->cow_id)
                                        ->select('animals.*', 'sheds.shed_number', 'animal_type.type_name')->first();
                                      } else {
                                          $dataInfo = DB::table('calf')
										  ->leftJoin('sheds', 'sheds.id', 'calf.shade_no')
                                          ->leftJoin('animal_type', 'animal_type.id', 'calf.animal_type')
										  ->where('calf.id', $cowInfoData->cow_id)
                                          ->select('calf.*', 'sheds.shed_number', 'animal_type.type_name')->first();
                                      }
									  
                                    ?>
                <tr>
                  <td class="center">000<?php echo e($dataInfo->id); ?></td>
                  <td class="left strong"><?php echo e($cowInfoData->cow_type==1 ? __('cow_sale.cow') : __('cow_sale.calf')); ?></td>
                  <td class="left"><?php echo e($dataInfo->type_name); ?> (<?php echo e($dataInfo->gender); ?>)</td>
                  <td class="right"><?php echo e(App\Library\farm::currency($cowInfoData->price)); ?></td>
                  <td class="right"><?php echo e(App\Library\farm::currency($cowInfoData->price)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php } ?>
                </tbody>
                
                <?php 
					$collect_payment = DB::table('cow_sale_payments')->where('sale_id', $single_data->id)->sum('pay_amount');
					$due_amount = 0;
					if(!empty($collect_payment) && (float)$collect_payment > 0){
						$due_amount = (float)$single_data->total_price - (float)$collect_payment;
					}
				?>
                <tfoot>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td align="right"><strong><?php echo e(__('invoice.total')); ?> : </strong> </td>
                    <td align="left"><?php echo e(App\Library\farm::currency($single_data->total_price)); ?></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td align="right"><strong><?php echo e(__('invoice.paid')); ?> : </strong> </td>
                    <td align="left"><?php echo e(App\Library\farm::currency(!empty($collect_payment) ? $collect_payment : 0)); ?></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td align="right"><strong><?php echo e(__('invoice.due')); ?> : </strong> </td>
                    <td align="left"><?php echo e(App\Library\farm::currency($due_amount)); ?></td>
                  </tr>
                </tfoot>
              </table>
            </div>
            <div class="row"> <?php if(!empty($due_amount) && (float)$due_amount > 0): ?>
              <div class="col-lg-8 paymentsttausbox">
                <div><img class="payment_status_icon" src="<?php echo e(asset("public/common/due.png")); ?>" /></div>
              </div>
              <?php else: ?>
              <div class="col-lg-8"><img class="payment_status_icon" src="<?php echo e(asset("public/common/paid.png")); ?>" /></div>
              <?php endif; ?> </div>
            <br/>
            <br/>
          </div>
        </div>
      </div>
      <div class="box-footer"> </div>
    </div>
  </div>
</section>
<?php echo Html::style('public/custom/css/print.css'); ?>

<input type="hidden" id="print_url_1" value='<?php echo Html::style("public/custom/css/bootstrap.min.css"); ?>' />
<input type="hidden" id="print_url_2" value='<?php echo Html::style("public/custom/css/print.css"); ?>' />
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/invoice/sale.blade.php ENDPATH**/ ?>