<div class="row">
  <div class="col-md-12 ajax-page-bb" align="center">
    <h3><?php echo e(__('cow_monitor.cow_details')); ?></h3>
  </div>
</div>
<div class="row ajax-page-pt15">
  <div class="col-md-12">
    <div class="col-md-6"> <?php if(isset($cow_score->new_images) && !empty($cow_score->new_images)): ?>
      <div class="owl-carousel cm-slider"> <?php $__currentLoopData = explode('_', $cow_score->new_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="img-thumbnail"><img src="<?php echo e(asset('storage/app/public/uploads/animal/'.$imageName)); ?>" /></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
      <?php else: ?>
      <div class="owl-carousel cm-slider"> <?php $__currentLoopData = explode('_', $single_data->pictures); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="img-thumbnail"><img src="<?php echo e(asset('storage/app/public/uploads/animal/'.$imageName)); ?>" /></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
      <?php endif; ?> </div>
    <div class="col-md-6 border">
      <table class="table table-bordered table-striped table-responsive">
        <tr>
          <td><b><?php echo e(__('cow_monitor.date_of_birth')); ?></b></td>
          <td><?php echo e((!empty($single_data->DOB))?Carbon\Carbon::parse($single_data->DOB)->format('M d, Y'):''); ?></td>
        </tr>
        <tr>
          <td><b><?php echo e(__('cow_monitor.animal_live_age')); ?></b></td>
          <td><?php echo e((!empty($single_data->age)) ? \App\Library\farm::animalAgeFormat($single_data->DOB) : ''); ?></td>
        </tr>
        <tr>
          <td><b><?php echo e(__('cow_monitor.buy_time_to_current')); ?></b></td>
          <td><?php echo e((!empty($single_data->buy_date)) ? \App\Library\farm::animalAgeFormat($single_data->buy_date) : ''); ?></td>
        </tr>
        <tr>
          <td><b><?php echo e(__('cow_monitor.animal_gender')); ?></b></td>
          <td><?php echo e($single_data->gender); ?></td>
        </tr>
        <tr>
          <td><b><?php echo e(__('cow_monitor.animal_type')); ?></b></td>
          <td><label class="label label-success lblfarm"><?php echo e((!empty($single_data->type_name)) ? $single_data->type_name : ''); ?></label></td>
        </tr>
        <?php if(!empty($cow_score->health_score)): ?>
        <tr>
          <td><b><?php echo e(__('cow_monitor.health_status')); ?></b></td>
          <td><?php
						$color = '';
						$message = '';
						$hc = $cow_score->health_score;
						if((int)$hc >= 80){
							$color = 'green';
							$message = __('cow_monitor.good_condition');
						} else if((int)$hc < 80 && (int)$hc > 50){
							$color = 'yellow';
							$message = __('cow_monitor.warning_condition');
						} else if((int)$hc <= 50){
							$color = 'red';
							$message = __('cow_monitor.danger_condition');
						}
					?>
            <div class="progress-group"> <span class="progress-text"><?php echo $message; ?></span> <span class="progress-number"><b><?php echo e($cow_score->health_score); ?> </b>/100</span>
              <div class="progress sm">
                <div class="progress-bar progress-bar-<?php echo $color; ?>" style="width: <?php echo e($cow_score->health_score); ?>%"></div>
              </div>
            </div></td>
        </tr>
        <?php endif; ?>
      </table>
    </div>
  </div>
</div>
<?php if(!empty($vaccine_pending)): ?>
<div class="row">
  <div class="col-md-12 ajax-page-bb" align="center">
    <h3 class="due-amount"><?php echo e(__('cow_monitor.five_pending_vaccine')); ?></h3>
  </div>
</div>
<div class="row ajax-page-pt15">
  <div class="col-md-12">
    <div class="col-md-12">
      <div>
        <table class="table table-bordered table-striped table-responsive">
          <thead>
            <tr>
              <th><?php echo e(__('cow_monitor.vaccine_name')); ?></th>
              <th><?php echo e(__('cow_monitor.time_days')); ?></th>
              <th class="th-center"><?php echo e(__('cow_monitor.repeat')); ?></th>
              <th><?php echo e(__('cow_monitor.dose')); ?></th>
              <th><?php echo e(__('cow_monitor.note')); ?></th>
            </tr>
          </thead>
          <tbody>
          
          <?php $__currentLoopData = $vaccine_pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pvl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($pvl->vaccine_name); ?></td>
            <td><?php echo e($pvl->months); ?></td>
            <td align="center"><?php if((bool)$pvl->repeat_vaccine): ?><i class="fa fa-check"></i><?php else: ?><i class="fa fa-close"></i><?php endif; ?></td>
            <td><?php echo e($pvl->dose); ?></td>
            <td><?php echo e($pvl->note); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>



<?php if(!empty($vaccines)): ?>
<div class="row">
  <div class="col-md-12 ajax-page-bb" align="center">
    <h3 class="color-monitor-text"><?php echo e(__('cow_vaccine_monitor.vaccine_done_list')); ?></h3>
  </div>
</div>
<div class="row  ajax-page-pt15">
  <div class="col-md-12">
    <div class="col-md-12"> <?php $__currentLoopData = $vaccines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vaccine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="panel panel-default">
        <div class="panel-body">
          <div class="form-group" align="center"><b><u><?php echo e(__('cow_vaccine_monitor.vaccine_date')); ?> : <?php echo e(Carbon\Carbon::parse($key)->format('m/d/Y')); ?></u></b></div>
          <?php if(!empty($vaccine['list'])): ?>
          <div>
            <table class="table table-bordered table-striped table-responsive">
              <thead>
                <tr>
                  <th><?php echo e(__('cow_vaccine_monitor.vaccine_name')); ?></th>
                  <th><?php echo e(__('cow_vaccine_monitor.remarks')); ?></th>
                  <th><?php echo e(__('cow_vaccine_monitor.given_time')); ?></th>
                </tr>
              </thead>
              <?php $__currentLoopData = $vaccine['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($list->vaccine_name); ?></td>
                <td><?php echo e($list->remarks); ?></td>
                <td><?php echo e($list->time); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
          <?php endif; ?>
          <div class="col-md-12" align="right"><b><?php echo e(__('cow_monitor.reported_by')); ?> <?php echo e($vaccine['name']); ?></b> (<?php echo e($vaccine['user_type']); ?>)</div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
  </div>
</div>
<?php endif; ?>
<?php /**PATH /home/vflhvhga/hadirinn/resources/views/cow-vaccine-monitor/ajax-animal.blade.php ENDPATH**/ ?>