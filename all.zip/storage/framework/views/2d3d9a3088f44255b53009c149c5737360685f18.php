
<?php $__env->startSection('title', __('designation.title')); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1><i class="icon-list"></i> <?php echo e(__('designation.title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"><?php echo e(__('designation.title')); ?></li>
  </ol>
</section>
<section class="content"> <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="#addModal" class="btn btn-success btn-sm" data-toggle="modal"> <i class="fa fa-plus-square"></i> <b><?php echo e(__('same.add_new')); ?></b> </a> <a href="<?php echo e(URL::to('designation')); ?>" class="btn btn-warning btn-sm"> <i class="fa fa-refresh"></i> <b><?php echo e(__('same.refresh')); ?></b> </a> </div>
    <div class="box-body">
      <div class="col-md-8 col-md-offset-2">
        <div class="table_scroll">
          <table class="table table-bordered table-striped table-responsive">
            <th><?php echo e(__('same.sl')); ?></th>
              <th><?php echo e(__('designation.designation')); ?></th>
              <th><?php echo e(__('same.action')); ?></th>
              <?php                           
                $number = 1;
                $numElementsPerPage = 10; // How many elements per page
                $pageNumber = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                $currentNumber = ($pageNumber - 1) * $numElementsPerPage + $number;
              ?>
            <tbody>
            
            <?php if(isset($alldata) && count($alldata)>0): ?>
            <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><label class="label label-success"><?php echo e($currentNumber++); ?></label></td>
              <td><?php echo e($data->name); ?></td>
              <td><div class="form-inline">
                  <div class = "input-group"> <a href="#editModal<?php echo e($data->id); ?>" class="btn btn-success btn-xs" data-toggle="modal" title="<?php echo e(__('same.edit')); ?>"><i class="icon-pencil"></i></a> </div>
                  <div class = "input-group"> <?php echo e(Form::open(array('route'=>['designation.destroy',$data->id],'method'=>'DELETE'))); ?>

                    <button type="submit" confirm="<?php echo e(__('same.delete_confirm')); ?>" class="btn btn-danger btn-xs confirm" title="<?php echo e(__('same.delete')); ?>"><i class="icon-trash"></i></button>
                    <?php echo Form::close(); ?> </div>
                </div>
                <!-- Modal Start -->
                <div class="modal fade" id="editModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog">
                  <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title"><i class="fa fa-edit edit-color"></i> <?php echo e(__('designation.update_designation')); ?></h4>
                      </div>
                      <?php echo Form::open(array('route' => ['designation.update', $data->id],'class'=>'form-horizontal','method'=>'PUT')); ?>

                      <div class="modal-body">
                        <div class="form-group">
                          <div class="col-md-12">
                            <label for="name"><?php echo e(__('designation.designation')); ?> <span class="validate">*</span> : </label>
                            <input type="text" class="form-control" value="<?php echo e($data->name); ?>" name="name" placeholder="<?php echo e(__('designation.designation')); ?>" required>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <div class="col-md-12" align="right"> <?php echo e(Form::submit(__('same.update'),array('class'=>'btn btn-warning btn-sm'))); ?> </div>
                      </div>
                      <?php echo Form::close(); ?> </div>
                    <!-- /.modal-content -->
                  </div>
                  <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
              <td colspan="3" align="center"> <?php echo e(__('same.empty_row')); ?></td>
            </tr>
            <?php endif; ?>
            </tbody>
            
          </table>
          <div align="center"><?php echo e($alldata->render()); ?></div>
        </div>
      </div>
    </div>
    <div class="box-footer"> </div>
  </div>
</section>
<!-- Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><i class="fa fa-plus-square color-green"></i> <?php echo e(__('designation.add_new_designation')); ?></h4>
      </div>
      <?php echo Form::open(array('route' => ['designation.store'],'class'=>'form-horizontal','method'=>'POST')); ?>

      <div class="modal-body">
        <div class="form-group">
          <div class="col-md-12">
            <label for="name"><?php echo e(__('designation.designation')); ?> <span class="validate">*</span> : </label>
            <input type="text" class="form-control" value="" name="name" placeholder="<?php echo e(__('designation.designation')); ?>" required>
          </div>
        </div>
      </div>
      <div class="modal-footer" align="right">
        <button type="button" class="btn btn-default btn-sm" data-dismiss="modal"><?php echo e(__('same.close')); ?></button>
        <?php echo e(Form::submit(__('same.save'),array('class'=>'btn btn-success btn-sm'))); ?> </div>
      <?php echo Form::close(); ?> </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vflhvhga/hadirinn/resources/views/designation/designationList.blade.php ENDPATH**/ ?>