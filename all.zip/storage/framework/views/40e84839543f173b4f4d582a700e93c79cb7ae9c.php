<?php $__env->startSection('title', __('salarylist.title')); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="icon-list"></i> <?php echo e(__('salarylist.title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"><a href="<?php echo e(URL::to('employee-salary')); ?>"><?php echo e(__('salarylist.title')); ?></a></li>
  </ol>
</section>
<!-- Main content -->
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('common.commonFunction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php $getMonthFromArr = months();?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="<?php echo e(url('employee-salary/create')); ?>" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> <b><?php echo e(__('salarylist.add_new')); ?></b></a> <a href="<?php echo e(url('employee-salary')); ?>" class="btn btn-warning btn-sm"><i class="fa fa-refresh"></i> <b><?php echo e(__('same.refresh')); ?></b></a> </div>
    <div class="box-body">
      <div class="table-responsive">
        <table class="table table-bordered table-striped table-responsive">
          <th><?php echo e(__('salarylist.sl')); ?></th>
            <th><?php echo e(__('salarylist.image')); ?></th>
            <th><?php echo e(__('salarylist.employee_name')); ?></th>
            <th><?php echo e(__('salarylist.pay_date')); ?></th>
            <th><?php echo e(__('salarylist.month')); ?></th>
            <th><?php echo e(__('salarylist.year')); ?></th>
            <th><?php echo e(__('salarylist.salary_amount')); ?></th>
            <th><?php echo e(__('salarylist.addition_amount')); ?></th>
            <th><?php echo e(__('salarylist.total')); ?></th>
            <th><?php echo e(__('same.action')); ?></th>
            <?php                           
                $number = 1;
                $numElementsPerPage = 10; // How many elements per page
                $pageNumber = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                $currentNumber = ($pageNumber - 1) * $numElementsPerPage + $number;
              ?>
          <tbody id="mainList">
          
          <?php if(!empty($salaryList)): ?>
          <?php $__currentLoopData = $salaryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><label class="label label-success"><?php echo e($currentNumber++); ?></label></td>
            <td> <?php if($data->image): ?>
              <?php $img = "storage/app/public/uploads/human-resource/".$data->image; ?>
              <?php if(file_exists($img)): ?> <img src='<?php echo e(asset($img)); ?>' class="img-thumbnail list_img_box"> <?php else: ?> <img src='<?php echo e(asset("public/custom/img/photo.png")); ?>' class="img-thumbnail list_img_box"> <?php endif; ?>
              <?php else: ?> <img src='<?php echo e(asset("public/custom/img/photo.png")); ?>' class="img-thumbnail list_img_box"> <?php endif; ?> </td>
            <td><?php echo e($data->employee_name); ?></td>
            <td><?php echo e(date('m/d/Y', strtotime($data->paydate))); ?></td>
            <td><?php echo e($getMonthFromArr[$data->month]); ?></td>
            <td><?php echo e($data->year); ?></td>
            <td class="amounts"><?php echo e(App\Library\farm::currency($data->salary)); ?></td>
            <td class="amounts"><?php echo e(App\Library\farm::currency($data->addition_money)); ?></td>
            <td class="amounts"><?php echo e(App\Library\farm::currency($data->salary+$data->addition_money)); ?></td>
            <td><div class="form-inline">
                <div class="input-group"> <a href="<?php echo e(route('employee-salary.edit', $data->id)); ?>" class="btn btn-success btn-xs" title="<?php echo e(__('same.edit')); ?>"><i class="icon-pencil"></i></a> </div>
                <div class="input-group"> <?php echo e(Form::open(array('route'=>['employee-salary.destroy',$data->id],'method'=>'DELETE'))); ?>

                  <button type="submit" class="btn btn-danger btn-xs confirm" confirm="<?php echo e(__('same.delete_confirm')); ?>"  title="<?php echo e(__('same.delete')); ?>"><i class="icon-trash"></i></button>
                  <?php echo Form::close(); ?> </div>
              </div></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <tr>
            <td colspan="8" align="center"><?php echo e(__('same.empty_row')); ?></td>
          </tr>
          <?php endif; ?>
          </tbody>
        </table>
        <div><?php echo e($salaryList->render()); ?></div>
      </div>
    </div>
    <!-- /.box-body -->
    <div class="box-footer"> </div>
    <!-- /.box-footer-->
  </div>
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/employee-salary/salary-list.blade.php ENDPATH**/ ?>