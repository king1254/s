<?php $__env->startSection('title', __('reports.expense_report_title')); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="fa fa-area-chart"></i> <?php echo e(__('reports.expense_report_title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"><a><?php echo e(__('reports.expense_report_title')); ?></a></li>
  </ol>
</section>
<!-- Main content -->
<?php
$configuration_data = \App\Library\farm::get_system_configuration('system_config');
$branch_info =  \App\Library\farm::branchInfo();
?>
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('common.commonFunction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-body">
      <div class="form-group"> <?php echo Form::open(array('url' => 'get-expense-report','class'=>'form-horizontal','autocomplete'=>'off','method' =>'GET')); ?>

        <div class="col-md-8 col-md-offset-2 mt20">
          <div class="panel panel-default">
            <div class="panel-heading"><i class="fa fa-calendar"></i> <?php echo e(__('reports.date_range')); ?></div>
            <div class="panel-body pb250"> <?php if(isset($date_from)): ?>
              <div class="col-md-4">
                <input name="date_from" value="<?php echo e(date('m/d/Y',strtotime($date_from))); ?>" id="date_from" class="form-control  wsit_datepicker" placeholder="<?php echo e(__('same.start_date')); ?>" type="text" selected>
              </div>
              <?php else: ?>
              <div class="col-md-4">
                <input name="date_from" value="" id="date_from" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.start_date')); ?>" type="text" selected>
              </div>
              <?php endif; ?>
              <?php if(isset($date_to)): ?>
              <div class="col-md-4"> <?php if($date_to !=''): ?>
                <input name="date_to" value="<?php echo e(date('m/d/Y',strtotime($date_to))); ?>" id="date_to" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.end_date')); ?>" type="text" selected>
                <?php else: ?>
                <input name="date_to" value="" id="date_to" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.end_date')); ?>" type="text" selected>
                <?php endif; ?> </div>
              <?php else: ?>
              <div class="col-md-4">
                <input name="date_to" value="" id="dateTo" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.end_date')); ?>" type="text" selected>
              </div>
              <?php endif; ?>
              <div class="col-md-4">
                <button type="submit" class="btn btn-success btn100"><i class="fa fa-search"></i> <?php echo e(__('same.search')); ?></button>
              </div>
            </div>
          </div>
        </div>
        <?php echo Form::close(); ?>

        <div class="clearfix"></div>
      </div>
      <hr/>
      <?php if(isset($hasData)): ?>
      <div class="table_scroll">
        <div id="print_icon"><a class="printReports" href="javascript:;"><img class="img-thumbnail" src='<?php echo e(asset("storage/app/public/common/print.png")); ?>'></a></div>
        <br>
        <br>
        <div id="printBox">
			<div id="printTable">
			  <div class="col-md-12 print-base">
				<p><?php if(!empty($configuration_data) && !empty($configuration_data->logo)): ?><img src="<?php echo e(asset("storage/app/public/uploads/$configuration_data->logo")); ?>"/><?php endif; ?></p>
				<p class="print-ptag"><?php if(!empty($configuration_data) && !empty($configuration_data->topTitle)): ?><?php echo e($configuration_data->topTitle); ?><?php endif; ?></p>
				<?php if(!empty($branch_info->branch_name)) { ?>
				<p class="print-ptag"><?php echo e($branch_info->branch_name); ?></p>
				<?php } ?>
				<p class="print-ptag"><?php echo e(__('reports.office_expense_report')); ?></p>
				<p class="print-ptag"><?php echo e(__('reports.for_date')); ?> : <?php echo e($date_from); ?> 
				  <?php if(isset($date_to)): ?>
				  - <?php echo e($date_to); ?> 
				  <?php endif; ?> </p>
			  </div>
			  <div class="table-div">
				<table class="table-print-style-1">
				  <thead>
					<tr>
					  <th><?php echo e(__('same.sl')); ?></th>
					  <th><?php echo e(__('same.date')); ?></th>
					  <th><?php echo e(__('reports.expense_purpose')); ?></th>
					  <th class="text-left"><?php echo e(__('reports.amount')); ?></th>
					</tr>
				  </thead>
				  <tbody>
					<?php $totalamount = 0; ?>
				  <?php if(isset($getJsonArr) && !empty($getJsonArr) && count($alldata)>0): ?>
				  <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  <?php $totalamount += $data->amount;?>
				  <tr>
					<td> <?php echo e($data->id); ?> </td>
					<td> <?php echo e(date('m/d/Y', strtotime($data->date))); ?> </td>
					<td> <?php echo e($data->purpose_name); ?> </td>
					<td align="left"> <?php echo e(App\Library\farm::currency($data->amount)); ?> </td>
				  </tr>
				  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  <?php else: ?>
				  <tr>
					<td colspan="10" align="center"><h2><?php echo e(__('same.empty_row')); ?></h2></td>
				  </tr>
				  <?php endif; ?>
				  </tbody>
				  
				  <tfoot>
					<tr>
					  <td colspan="3" align="right"><strong><?php echo e(__('same.total')); ?> :</strong></td>
					  <td><?php echo e(App\Library\farm::currency($totalamount)); ?></td>
					</tr>
				  </tfoot>
				</table>
			  </div>
			</div>
		</div>
      </div>
      <?php endif; ?> </div>
  </div>
  <!-- /.box -->
</section>
<?php echo Html::style('public/custom/css/report.css'); ?>

<input type="hidden" id="print_url_1" value='<?php echo Html::style("public/custom/css/bootstrap.min.css"); ?>' />
<input type="hidden" id="print_url_2" value='<?php echo Html::style("public/custom/css/report.css"); ?>' />
<input type="hidden" id="print_url_3" value='<?php echo Html::style("public/custom/css/AdminLTE.css"); ?>' />
<!-- /.content -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/reports/office-expense-report.blade.php ENDPATH**/ ?>