<?php $__env->startSection('title', __('reports.vaccine_wise_monitoring')); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="fa fa-area-chart"></i> <?php echo e(__('reports.vaccine_wise_monitoring')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"><a><?php echo e(__('reports.vaccine_wise_monitoring')); ?></a></li>
  </ol>
</section>
<?php
$configuration_data = \App\Library\farm::get_system_configuration('system_config');
$branch_info =  \App\Library\farm::branchInfo();
?>
<!-- Main content -->
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('common.commonFunction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-body">
      <div class="form-group"> <?php echo Form::open(array('url' => 'get-vaccine-wise-monitoring-report','class'=>'form-horizontal','autocomplete'=>'off','method' =>'GET')); ?>

        <div class="col-md-12">
          <div class="panel panel-default mt20">
            <div class="panel-heading"><i class="fa fa-search"></i> <?php echo e(__('reports.search_fields')); ?></div>
            <div class="panel-body pb250">
              <div class="col-md-3">
                <select class="form-control" name="shed_no">
                  <option value="0"><?php echo e(__('reports.select_a_stall')); ?></option>
                  <?php $__currentLoopData = $shedArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shedArrData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($shedArrData->id); ?>" <?php echo e(isset($shed_no)?($shed_no==$shedArrData->id)?'selected':'':''); ?>><?php echo e($shedArrData->shed_number); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-3">
                <select class="form-control" name="vaccine_id" required>
                  <option value=""><?php echo e(__('reports.select_a_vaccine')); ?></option>
                  <?php $__currentLoopData = $vaccine_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaccineArrData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($vaccineArrData->id); ?>" <?php echo e(isset($vaccine_id)?($vaccine_id==$vaccineArrData->id)?'selected':'':''); ?>><?php echo e($vaccineArrData->vaccine_name); ?> - ( <?php echo e($vaccineArrData->months); ?> Months )</option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <?php if(isset($date_from)): ?>
              <div class="col-md-3">
                <input name="date_from" value="<?php echo e($date_from); ?>" id="date_from" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.start_date')); ?>" type="text" selected required>
              </div>
              <?php else: ?>
              <div class="col-md-3">
                <input name="date_from" value="" id="date_from" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.start_date')); ?>" type="text" selected required>
              </div>
              <?php endif; ?>
              <?php if(isset($date_to)): ?>
              <div class="col-md-3"> <?php if($date_to !=''): ?>
                <input name="date_to" value="<?php echo e($date_to); ?>" id="date_to" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.end_date')); ?>" type="text" selected required>
                <?php else: ?>
                <input name="date_to" value="" id="date_to" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.end_date')); ?>" type="text" selected required>
                <?php endif; ?> </div>
              <?php else: ?>
              <div class="col-md-3">
                <input name="date_to" value="" id="dateTo" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.end_date')); ?>" type="text" selected required>
              </div>
              <?php endif; ?>
              <div class="col-md-12"> <br>
                <button type="submit" class="btn btn-success btn100"><i class="fa fa-search"></i> <?php echo e(__('same.search')); ?></button>
              </div>
            </div>
          </div>
        </div>
        <?php echo Form::close(); ?>

        <div class="clearfix"></div>
      </div>
      <?php if(isset($hasData)): ?>
      <div class="table_scroll">
        <div id="print_icon"><a class="printReports" href="javascript:;"><img class="img-thumbnail" src='<?php echo e(asset("storage/app/public/common/print.png")); ?>'></a></div>
        <br>
        <br>
        <div id="printBox">
          <div id="printTable">
            <div class="col-md-12 print-base">
              <p><?php if(!empty($configuration_data) && !empty($configuration_data->logo)): ?><img src="<?php echo e(asset("storage/app/public/uploads/$configuration_data->logo")); ?>"/><?php endif; ?></p>
              <p class="print-ptag"><?php if(!empty($configuration_data) && !empty($configuration_data->topTitle)): ?><?php echo e($configuration_data->topTitle); ?><?php endif; ?></p>
              <?php if(!empty($branch_info->branch_name)) { ?>
              <p class="print-ptag"><?php echo e($branch_info->branch_name); ?></p>
              <?php } ?>
              <p class="print-ptag"><?php echo e(__('reports.vaccine_wise_monitoring')); ?></p>
              <p class="print-ptag"><?php echo e(__('reports.for_date')); ?> : <?php echo e($date_from); ?> 
                <?php if(isset($date_to)): ?>
                - <?php echo e($date_to); ?> 
                <?php endif; ?> </p>
            </div>
            <div class="table-div">
              <table class="table-print-style-1">
                <thead>
                  <tr>
                    <th><?php echo e(__('same.sl')); ?></th>
                    <th><?php echo e(__('same.date')); ?></th>
                    <th><?php echo e(__('reports.stall_no')); ?></th>
                    <th><?php echo e(__('reports.animal_id')); ?></th>
                    <th><?php echo e(__('reports.vaccine_status')); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sl = 0; ?>
                <?php if(isset($getJsonArr) && !empty($getJsonArr) && count($alldata)>0): ?>
                <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $check = DB::table('cow_vaccine_monitor')
                            ->leftJoin('cow_vaccine_monitor_dtls', 'cow_vaccine_monitor_dtls.monitor_id', 'cow_vaccine_monitor.id')
                            ->where('cow_vaccine_monitor.cow_id', $data->id)
                            ->whereBetween('cow_vaccine_monitor.date', [date('Y-m-d', strtotime($date_from)), date('Y-m-d', strtotime($date_to))])
                            ->where('cow_vaccine_monitor_dtls.vaccine_id', $vaccine_id)
                            ->exists();
                  ?>
                <?php if($check==true): ?>
                <?php  
                        $getData = DB::table('cow_vaccine_monitor')
                            ->leftJoin('cow_vaccine_monitor_dtls', 'cow_vaccine_monitor_dtls.monitor_id', 'cow_vaccine_monitor.id')
                            ->where('cow_vaccine_monitor.cow_id', $data->id)
                            ->whereBetween('cow_vaccine_monitor.date', [date('Y-m-d', strtotime($date_from)), date('Y-m-d', strtotime($date_to))])
                            ->where('cow_vaccine_monitor_dtls.vaccine_id', $vaccine_id)
                            ->select('cow_vaccine_monitor.date')
                            ->get();
                      ?>
                <?php $__currentLoopData = $getData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getDataInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td> <?php echo e(++$sl); ?> </td>
                  <td> <?php echo e(date('m/d/Y', strtotime($getDataInfo->date))); ?> </td>
                  <td> <?php echo e($data->shed_number); ?> </td>
                  <td> 000<?php echo e($data->id); ?> </td>
                  <td><label class="label label-success"><?php echo e(__('same.yes')); ?></label>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <tr>
                  <td> <?php echo e(++$sl); ?> </td>
                  <td>&nbsp;</td>
                  <td> <?php echo e($data->shed_number); ?> </td>
                  <td> 000<?php echo e($data->id); ?> </td>
                  <td><label class="label label-danger"><?php echo e(__('same.no')); ?></label>
                  </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <tr>
                  <td colspan="5" align="center"><h2><?php echo e(__('same.empty_row')); ?></h2></td>
                </tr>
                <?php endif; ?>
                </tbody>
                
              </table>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?> </div>
  </div>
  <!-- /.box -->
</section>
<?php echo Html::style('public/custom/css/report.css'); ?>

<input type="hidden" id="print_url_1" value='<?php echo Html::style("public/custom/css/bootstrap.min.css"); ?>' />
<input type="hidden" id="print_url_2" value='<?php echo Html::style("public/custom/css/report.css"); ?>' />
<input type="hidden" id="print_url_3" value='<?php echo Html::style("public/custom/css/AdminLTE.css"); ?>' />
<!-- /.content -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/reports/vaccine-wise-monitoring-report.blade.php ENDPATH**/ ?>