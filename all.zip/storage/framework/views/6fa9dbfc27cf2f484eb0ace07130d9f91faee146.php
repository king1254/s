
<?php $__env->startSection('title', __('cow_feed.title_entry')); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="fa fa-cutlery"></i> <?php echo e(__('cow_feed.title_entry')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
	<li class="active"><?php echo e(__('cow_feed.title_entry')); ?></li>
  </ol>
</section>
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('common.commonFunction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success"> <?php if(empty($single_data)): ?>
    <?php echo e(Form::open(array('route' => 'cow-feed.store', 'method' => 'post', 'files' => true))); ?>

    <?php $btn_name = __('same.save'); ?>
    <?php else: ?>
    <?php echo e(Form::open(array('route' => ['cow-feed.update',$single_data->id], 'method' => 'PUT', 'files' => true))); ?>

    <?php $btn_name = __('same.update'); ?>
    <?php endif; ?>
    <div class="box-header with-border" align="right">
      <button type="submit" class="btn btn-success btn-sm"><i class="fa fa-floppy-o"></i> <b><?php echo e($btn_name); ?> <?php echo e(__('same.information')); ?></b></button>
      <a href="<?php echo e(url('cow-feed/create')); ?>" class="btn btn-warning btn-sm"><i class="fa fa-refresh"></i> <b> <?php echo e(__('same.refresh')); ?></b></a> &nbsp;&nbsp; </div>
    <div class="box-body">
      <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
          <div class="panel-heading feed-heading feed-heading"><i class="fa fa-info-circle"></i>&nbsp;<?php echo e(__('cow_feed.basic_information')); ?> :</div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-12">
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="shed_no"><?php echo e(__('cow_feed.stall_no')); ?> <span class="validate">*</span> : </label>
                    <select class="form-control loadCow" name="shed_no" id="shed_no" data-url="<?php echo e(URL::to('load-cow')); ?>" required>
                      <option value=""><?php echo e(__('same.select')); ?></option>
						<?php $__currentLoopData = $all_sheds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sheds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      		<option value="<?php echo e($sheds->id); ?>" <?php echo e((!empty($single_data))?($sheds->id==$single_data->shed_no)?'selected':'':''); ?>><?php echo e($sheds->shed_number); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="cow_id"><?php echo e(__('cow_feed.cow_no')); ?> <span class="validate">*</span> : </label>
                    <select class="form-control" name="cow_id" id="cow_id" required>
                      <option value=""><?php echo e(__('same.select')); ?></option>
						<?php if(isset($single_data)): ?>
							<?php $__currentLoopData = $cowArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cowArrData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      			<option value="<?php echo e($cowArrData->id); ?>" <?php echo e(($cowArrData->id==$single_data->cow_id)?'selected':''); ?>>000<?php echo e($cowArrData->id); ?></option>
						    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="date"><?php echo e(__('cow_feed.date')); ?> <span class="validate">*</span> : </label>
                    <input type="text" name="date" class="form-control wsit_datepicker" value="<?php echo e((!empty($single_data->date))?date('m/d/Y', strtotime($single_data->date)):''); ?>" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="note"><?php echo e(__('cow_feed.note')); ?> : </label>
                    <textarea name="note" class="form-control"><?php echo e((!empty($single_data->note))?$single_data->note:''); ?></textarea>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
          <div class="panel-heading feed-heading"><i class="fa fa-info-circle"></i>&nbsp;<?php echo e(__('cow_feed.feed_informations')); ?> :</div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-12">
                <table class="table table-responsive table-bordered table-striped">
                  <th><?php echo e(__('cow_feed.item_name')); ?></th>
                    <th><?php echo e(__('cow_feed.item_quantity')); ?></th>
                    <th><?php echo e(__('cow_feed.unit')); ?></th>
                    <th><?php echo e(__('cow_feed.feeding_time')); ?></th>
                  <tbody>
                    <?php $row = 1; ?>
                  <?php $__currentLoopData = $food_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food_item_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(isset($single_data)): ?>
                  <?php  
						$checkData = DB::table('cow_feed_dtls')
									 ->where('feed_id', $single_data->id)
									 ->where('item_id', $food_item_data->id)
									 ->exists();
						if($checkData==true){
							$savedData = DB::table('cow_feed_dtls')
									 ->where('feed_id', $single_data->id)
									 ->where('item_id', $food_item_data->id)
									 ->first();
						}
					?>
                  <?php endif; ?>
                  <tr>
                    <td><label class="checkbox-inline">
                      <input type="checkbox" name="cow_feed[<?php echo e($row); ?>][item_id]" value="<?php echo e($food_item_data->id); ?>" <?php echo e((isset($checkData)?($checkData==true)?'checked':'':'')); ?>>
                      <?php echo e($food_item_data->name); ?> </label>
                    </td>
                    <td><input type="text" name="cow_feed[<?php echo e($row); ?>][qty]" class="form-control" value="<?php echo e((isset($checkData)?($checkData==true)?$savedData->qty:'':'')); ?>">
                    </td>
                    <td><select name="cow_feed[<?php echo e($row); ?>][unit_id]" class="form-control">
                        <option value=""><?php echo e(__('same.select')); ?></option>
		    				<?php $__currentLoopData = $food_units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food_unit_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        		<option value="<?php echo e($food_unit_data->id); ?>" <?php echo e((isset($checkData)?($checkData==true)?($savedData->unit_id==$food_unit_data->id)?'selected':'':'':'')); ?>>
                        <?php echo e($food_unit_data->name); ?> </option>
		    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </td>
                    <td><input type="text" name="cow_feed[<?php echo e($row); ?>][time]" class="form-control" placeholder="<?php echo e(__('cow_feed.time_example')); ?>" value="<?php echo e((isset($checkData)?($checkData==true)?$savedData->time:'':'')); ?>">
                    </td>
                  </tr>
                  <?php $row++; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php echo Form::close(); ?> </div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vflhvhga/hadirinn/resources/views/cow-feed/form.blade.php ENDPATH**/ ?>