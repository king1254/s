<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title><?php echo e(__('login.title')); ?></title>
<!-- Tell the browser to be responsive to screen width -->
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<!-- Bootstrap 3.3.7 -->
<?php echo Html::style('public/custom/css/bootstrap.min.css'); ?>

<!-- Font Awesome -->
<?php echo Html::style('public/custom/css_icon/font-awesome/css/font-awesome.min.css'); ?>

<!-- Ionicons -->
<?php echo Html::style('public/custom/css_icon/Ionicons/css/ionicons.min.css'); ?>

<?php echo Html::style('public/custom/css/reset.min.css'); ?>


<?php echo Html::style('public/custom/css/login.css'); ?>

<!-- jQuery 3 -->
<?php echo Html::script('public/custom/js/plugins/jquery/dist/jquery.min.js'); ?>

<!-- Bootstrap 3.3.7 -->
<?php echo Html::script('public/custom/js/plugins/bootstrap/dist/js/bootstrap.min.js'); ?>

</head>
<body>
<div class="container"> </div>
<?php $configuration_data = \App\Library\farm::get_system_configuration('system_config'); ?>
<div class="form">
  <div class="image_holder"> <?php if(!empty($configuration_data) && !empty($configuration_data->logo)): ?><img src="<?php echo e(asset("storage/app/public/uploads/$configuration_data->logo")); ?>"/><?php endif; ?>
    <div class="login-page-title"><?php if(!empty($configuration_data) && !empty($configuration_data->loginTitle)): ?><?php echo e($configuration_data->loginTitle); ?><?php endif; ?></div>
  </div>
  <?php if(Session::get('error')): ?>
  <div class="custom-alerts alert alert-danger fade in">
    <ul>
      <li><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <?php echo e(Session::get('error')); ?></li>
      <?php Session::put('error', NULL); ?>
    </ul>
  </div>
  <?php elseif($errors->has('email')): ?>
  <div class="custom-alerts alert alert-danger fade in"> <strong><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <?php echo e($errors->first('email')); ?></strong> </div>
  <?php endif; ?>
  <form name="form" action="<?php echo e(url('/login')); ?>"  class="login-form" method="POST" id="form">
    <?php echo e(csrf_field()); ?>

    <input id="email" type="text" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('login.email')); ?>" required>
    <input id="password" type="password" name="password" placeholder="<?php echo e(__('login.password')); ?>" required>
    <button type="submit" class="btn btn-primary"> <?php echo e(__('login.login')); ?></button>
  </form>
</div>
</body>
</html>
<?php /**PATH /home/vflhvhga/hadirinn/resources/views/auth/login.blade.php ENDPATH**/ ?>