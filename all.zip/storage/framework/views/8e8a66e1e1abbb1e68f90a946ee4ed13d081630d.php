
<?php $__env->startSection('title', __('user_type.title')); ?>
<?php $__env->startSection('content'); ?>
<?php 
  use App\Library\UserRoleWiseAccess;
  $allControllerList = UserRoleWiseAccess::controllerMethods();
?>
<section class="content-header">
  <h1><i class="icon-list"></i> <?php echo e(__('user_type.title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"><?php echo e(__('user_type.title')); ?></li>
  </ol>
</section>
<section class="content"> <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="#addNew" data-toggle="modal" class="btn btn-success btn-sm"> <i class="fa fa-plus-square"></i> <b><?php echo e(__('same.add_new')); ?></b> </a> <a href="<?php echo e(url('user-type')); ?>" class="btn btn-warning btn-sm"> <i class="fa fa-refresh"></i> <b><?php echo e(__('same.refresh')); ?></b> </a> </div>
    <div class="box-body">
      <div class="col-md-8 col-md-offset-2">
        <div class="table_scroll">
          <table class="table table-bordered table-striped table-responsive">
            	<th><?php echo e(__('same.sl')); ?></th>
              	<th><?php echo e(__('user_type.user_type')); ?></th>
              	<th><?php echo e(__('same.action')); ?></th>
            <tbody>
              <?php                           
                $number = 1;
                $numElementsPerPage = 10; // How many elements per page
                $pageNumber = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                $currentNumber = ($pageNumber - 1) * $numElementsPerPage + $number;
              ?>
            <?php if(isset($alldata) && count($alldata)): ?>
            <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><label class="label label-success"><?php echo e($currentNumber++); ?></label></td>
              <td><?php echo e($data->user_type); ?></td>
              <td><div class="form-inline">
                  <div class = "input-group"> <a href="#editModal<?php echo e($data->id); ?>" class="btn btn-success btn-xs" data-toggle="modal" title="<?php echo e(__('same.edit')); ?>"><i class="icon-pencil"></i></a> </div>
                </div>
                <!-- Modal Start -->
                <div class="modal fade" id="editModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title"><b><i class="fa fa-shield edit-color"></i> <span><?php echo e(__('user_type.update_user_type_access')); ?></span></b></h4>
                      </div>
                      <?php echo Form::open(array('route' => ['user-type.update', $data->id],'class'=>'form-horizontal','method'=>'PUT')); ?>

                      <div class="modal-body">
                        <div class="form-group">
                          <div class="col-md-12">
                            <div class="col-md-12">
                              <label for="user_type"><?php echo e(__('user_type.user_type')); ?> : <span class="validate">*</span></label>
                              <input type="text" name="user_type" value="<?php echo e($data->user_type); ?>" class="form-control" placeholder="<?php echo e(__('user_type.user_type')); ?>" required>
                            </div>
                          </div>
                        </div>
                        <?php $selectedControllerArr = json_decode($data->user_role, true); ?>
                        <div class="form-group">
                          <div class="col-md-12 userTypeBg">
                            <div class="col-md-12">
                              <label class="checkbox-inline user-type-checkbox-inline">
                              <input type="checkbox" name="checkAll" class="checkAll" id="<?php echo e($data->id); ?>">
                              <span><?php echo e(__('user_type.give_all_access')); ?></span> </label>
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-12">
                            <table class="table table-responsive table-striped table-bordered" id="checkboxBlock_<?php echo e($data->id); ?>">
                              <?php $j=1; ?>
                              <?php $__currentLoopData = $allControllerList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $controllerName => $accessName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td class="box-middle"><label class="label label-success"><?php echo e($j); ?></label>
                                </td>
                                <td class="ut-pt-2"> <?php $__currentLoopData = $accessName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actionName => $actionText): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if(isset($selectedControllerArr[$controllerName][$actionName])): ?>
                                  <div class="col-md-4">
                                    <label class="checkbox-inline checkbox-inline-box-2">
                                    <input type="checkbox" class="<?php echo e($data->id); ?>_subAction_<?php echo e($j); ?>" name="useraccess[<?php echo e($controllerName); ?>][<?php echo e($actionName); ?>]" value="<?php echo e($actionName); ?>" checked>
                                    <?php echo e($actionText); ?> </label>
                                  </div>
                                  <?php else: ?>
                                  <div class="col-md-4">
                                    <label class="checkbox-inline checkbox-inline-box-2">
                                    <input type="checkbox" class="<?php echo e($data->id); ?>_subAction_<?php echo e($j); ?>" name="useraccess[<?php echo e($controllerName); ?>][<?php echo e($actionName); ?>]" value="<?php echo e($actionName); ?>">
                                    <?php echo e($actionText); ?> </label>
                                  </div>
                                  <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </td>
                              </tr>
                              <?php $j++; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <div class="col-md-12" align="right">
                          <button type="button" class="btn btn-default btn-sm" data-dismiss="modal"> <?php echo e(__('same.close')); ?> </button>
                          <?php echo e(Form::submit(__('same.update'),array('class'=>'btn btn-warning btn-sm'))); ?> </div>
                      </div>
                      <?php echo Form::close(); ?> </div>
                    <!-- /.modal-content -->
                  </div>
                  <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
              <td colspan="3" align="center"> <?php echo e(__('same.empty_row')); ?> </td>
            </tr>
            <?php endif; ?>
            </tbody>
            
          </table>
        </div>
      </div>
    </div>
    <!-- Modal Start -->
    <div class="modal fade" id="addNew" tabindex="-1" role="dialog">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title"><b><i class="fa fa-shield color-monitor-text"></i> <span><?php echo e(__('user_type.add_user_type_access')); ?></span></b></h4>
          </div>
          <?php echo Form::open(array('route' => ['user-type.store'],'class'=>'form-horizontal','method'=>'POST')); ?>

          <div class="modal-body">
            <div class="form-group">
              <div class="col-md-12">
                <div class="col-md-12">
                  <label for="user_type"><?php echo e(__('user_type.user_type')); ?> : <span class="validate">*</span></label>
                  <input type="text" name="user_type" value="" class="form-control" placeholder="<?php echo e(__('user_type.user_type')); ?>">
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="col-md-12 userTypeBg">
                <div class="col-md-12">
                  <label class="checkbox-inline user-type-checkbox-inline">
                  <input type="checkbox" name="checkAll" class="checkAll" id="all">
                  <span><?php echo e(__('user_type.give_all_access')); ?></span> </label>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="col-md-12">
                <table class="table table-responsive table-striped table-bordered" id="checkboxBlock_all">
                  <?php $j=1; ?>
                  <?php $__currentLoopData = $allControllerList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $controllerName => $accessName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="box-middle"><label class="label label-success"><?php echo e($j); ?></label>
                    </td>
                    <td class="ut-pt-2"> <?php $__currentLoopData = $accessName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actionName => $actionText): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-md-4">
                        <label class="checkbox-inline checkbox-inline-box-2">
                        <input type="checkbox" class="<?php echo e($data->id); ?>_subAction_<?php echo e($j); ?>" name="useraccess[<?php echo e($controllerName); ?>][<?php echo e($actionName); ?>]" value="<?php echo e($actionName); ?>">
                        <?php echo e($actionText); ?> </label>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </td>
                  </tr>
                  <?php $j++; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <div class="col-md-12" align="right">
              <button type="button" class="btn btn-default btn-sm" data-dismiss="modal"> <?php echo e(__('same.close')); ?> </button>
              <?php echo e(Form::submit(__('same.save'),array('class'=>'btn btn-success btn-sm'))); ?> </div>
          </div>
          <?php echo Form::close(); ?> </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
    <div class="box-footer"> </div>
  </div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vflhvhga/hadirinn/resources/views/userType/index.blade.php ENDPATH**/ ?>