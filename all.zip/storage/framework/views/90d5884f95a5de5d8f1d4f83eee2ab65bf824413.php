<?php $__env->startSection('title', __('reports.salary_report_title')); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1><i class="fa fa-area-chart"></i> <?php echo e(__('reports.salary_report_title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"><a href="<?php echo e(URL::to('employee-salary-report')); ?>"> <?php echo e(__('reports.salary_report_title')); ?></a></li>
  </ol>
</section>
<?php
$configuration_data = \App\Library\farm::get_system_configuration('system_config');
$branch_info =  \App\Library\farm::branchInfo();
?>
<section class="content"> <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('common.commonFunction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-body">
      <div class="form-group">
        <div class="col-md-12">
          <div class="panel panel-default mt20">
            <div class="panel-heading"> <i class="fa fa-info-circle"></i> <?php echo e(__('reports.search_title')); ?> </div>
            <div class="panel-body"> <?php echo Form::open(array('route' => 'employee-salary-report.store','class'=>'form-horizontal','method' =>'POST')); ?>

              <div class="col-md-3">
                <select class="form-control" name="month">
                  <option value="0"><?php echo e(__('reports.select_a_month')); ?></option>
                    <?php $__currentLoopData = months(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($key); ?>" <?php echo e((!empty($selected_month))?($selected_month==$key)?'selected':'':''); ?>><?php echo e($months); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-3">
                <select class="form-control" name="year">
                  <option value="0"><?php echo e(__('reports.select_a_year')); ?></option>
                    <?php $__currentLoopData = years(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($year); ?>" <?php echo e((!empty($selected_year))?($selected_year==$year)?'selected':'':''); ?>><?php echo e($year); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-3">
                <select class="form-control" name="employee_id">
                  <option value="0"><?php echo e(__('reports.select_an_employee')); ?></option>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($employee->id); ?>" <?php echo e((!empty($selected_employee_id))?($selected_employee_id==$employee->id)?'selected':'':''); ?>><?php echo e($employee->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-3">
                <button type="submit" class="btn btn-success print-submit"> <i class="fa fa-search"></i> <?php echo e(__('same.search')); ?></button>
              </div>
              <?php echo Form::close(); ?> </div>
          </div>
        </div>
        <div class="clearfix"></div>
      </div>
    </div>
  </div>
  <?php if(isset($result)): ?>
  <?php if(!empty($result)): ?>
  <div class="box box-success">
    <div class="box-body">
      <div id="print_icon"><a class="printReports" href="javascript:;"><img class="img-thumbnail" src='<?php echo e(asset("storage/app/public/common/print.png")); ?>'></a></div>
      <br>
      <br>
      <div id="printBox">
        <div class="table-responsive" id="printTable">
          <div class="col-md-12 print-base">
            <p><?php if(!empty($configuration_data) && !empty($configuration_data->logo)): ?><img src="<?php echo e(asset("storage/app/public/uploads/$configuration_data->logo")); ?>"/><?php endif; ?></p>
            <p class="print-ptag"><?php if(!empty($configuration_data) && !empty($configuration_data->topTitle)): ?><?php echo e($configuration_data->topTitle); ?><?php endif; ?></p>
            <?php if(!empty($branch_info->branch_name)) { ?>
            <p class="print-ptag"><?php echo e($branch_info->branch_name); ?></p>
            <?php } ?>
            <p class="print-ptag"><?php echo e(__('reports.employee_salary_report')); ?></p>
          </div>
          <table class="table-print-style-2">
            <tr class="header-top">
              <th class="text-center"><?php echo e(__('reports.pay_date')); ?></th>
              <th><?php echo e(__('reports.employee_name')); ?></th>
              <th><?php echo e(__('reports.contact_number')); ?></th>
              <th><?php echo e(__('reports.designation')); ?></th>
              <th class="text-right"><?php echo e(__('reports.salary_amount')); ?></th>
              <th class="text-right"><?php echo e(__('reports.addition_amount')); ?></th>
              <th class="text-right"><?php echo e(__('reports.total_pay_amount')); ?></th>
              <th class="text-center"><?php echo e(__('reports.remarks')); ?></th>
            </tr>
            <tbody>
              <?php 
              $year_arr = array(); $month_arr=array(); 
              $totalSalary = $totalAddition = $final = 0;
            ?>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(!in_array($salary_data->year, $year_arr)): ?>
            <?php $year_arr[$salary_data->year]=$salary_data->year; ?>
            <tr>
              <td colspan="8" class="report-year"> <?php echo e(__('reports.year')); ?> : <?php echo e($salary_data->year); ?> </td>
            </tr>
            <?php endif; ?>
            
            <?php if(empty($month_arr[$salary_data->year][$salary_data->month])): ?>
            <?php $month_arr[$salary_data->year][$salary_data->month]=$salary_data->month; ?>
            <tr>
              <td colspan="8" class="report-month"> <?php echo e(__('reports.month')); ?> : <?php echo e(months()[$salary_data->month]); ?> </td>
            </tr>
            <?php endif; ?>
            <tr class="base-loop-row">
              <td class="text-center"><?php echo e(date('m/d/Y', strtotime($salary_data->paydate))); ?></td>
              <td><?php echo e($salary_data->name); ?></td>
              <td><?php echo e($salary_data->phone_no); ?></td>
              <td><?php echo e($salary_data->designation_name); ?></td>
              <td class="text-right"> <?php echo e(App\Library\farm::currency($salary_data->salary)); ?>

                <?php  
                    $totalSalary += $salary_data->salary;
                  ?>
              </td>
              <td class="text-right"> <?php echo e(App\Library\farm::currency($salary_data->addition_money)); ?>

                <?php  
                    $totalAddition += $salary_data->addition_money;
                  ?>
              </td>
              <td class="text-right"> <?php echo e(App\Library\farm::currency($salary_data->salary+$salary_data->addition_money)); ?>

                <?php 
                    $final += $salary_data->salary+$salary_data->addition_money;
                  ?>
              </td>
              <td class="text-center"><?php echo e($salary_data->note); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
            <tfoot>
              <tr>
                <th class="text-right" colspan="4"><?php echo e(__('same.total')); ?> : </th>
                <th class="text-right"> <?php echo e(App\Library\farm::currency($totalSalary)); ?> </th>
                <th class="text-right"> <?php echo e(App\Library\farm::currency($totalAddition)); ?> </th>
                <th class="text-right"> <?php echo e(App\Library\farm::currency($final)); ?> </th>
                <th class="text-center">&nbsp;</th>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
    <!-- /.box-body -->
    <div class="box-footer"> </div>
    <!-- /.box-footer-->
  </div>
  <?php else: ?>
  <div class="box box-success">
    <div class="box-body" align="center" class="salarynoprintdata"><?php echo e(__('same.empty_row')); ?></div>
  </div>
  <?php endif; ?>
  <?php endif; ?>
  <!-- /.box -->
</section>
<?php echo Html::style('public/custom/css/report.css'); ?>

<input type="hidden" id="print_url_1" value='<?php echo Html::style("public/custom/css/bootstrap.min.css"); ?>' />
<input type="hidden" id="print_url_2" value='<?php echo Html::style("public/custom/css/report.css"); ?>' />
<input type="hidden" id="print_url_3" value='<?php echo Html::style("public/custom/css/AdminLTE.css"); ?>' />
<!-- /.content -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/reports/employeeSalaryReport.blade.php ENDPATH**/ ?>