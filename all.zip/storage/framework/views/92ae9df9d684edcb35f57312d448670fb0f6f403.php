<?php $__env->startSection('title', __('reports.animal_statistics')); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="fa fa-pie-chart"></i> <?php echo e(__('reports.animal_statistics')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
	<li class="active"><?php echo e(__('reports.animal_statistics')); ?></li>
  </ol>
</section>
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('common.commonFunction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="<?php echo e(url('animal-statistics')); ?>" class="btn btn-warning btn-sm"><i class="fa fa-refresh"></i> <b> <?php echo e(__('same.refresh')); ?></b></a> &nbsp;&nbsp; </div>
    <div class="box-body">
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading feed-heading"><i class="icon-list"></i>&nbsp;<?php echo e(__('reports.animal_statistics_report')); ?> :</div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-12">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="shed_no"><?php echo e(__('reports.stall_no')); ?> <span class="validate">*</span> : </label>
                    <select class="form-control load-cow-statistics-page" name="shed_no" id="shed_no" data-url="<?php echo e(URL::to('load-cow-report')); ?>" required>
                      	<option value="0"><?php echo e(__('same.select')); ?></option>
						<?php $__currentLoopData = $all_sheds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sheds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      		<option value="<?php echo e($sheds->id); ?>" <?php echo e((!empty($single_data))?($sheds->id==$single_data->shed_no)?'selected':'':''); ?>><?php echo e($sheds->shed_number); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="cow_id"><?php echo e(__('reports.animal_id')); ?> <span class="validate">*</span> : </label>
                    <select class="form-control animal-ajax-statistics" name="cow_id" id="cow_id" data-url="<?php echo e(URL::to('animal-monitor-statistics')); ?>" required>
                      	<option value="0"><?php echo e(__('same.select')); ?></option>
						<?php if(isset($single_data)): ?>
							<?php $__currentLoopData = $cowArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cowArrData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  							<option value="<?php echo e($cowArrData->id); ?>" <?php echo e(($cowArrData->id==$single_data->cow_id)?'selected':''); ?>>000<?php echo e($cowArrData->id); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
								    
                    </select>
                  </div>
                </div>
                <div class="col-md-12" id="animal-details" align="center"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/animal-statistics/index.blade.php ENDPATH**/ ?>