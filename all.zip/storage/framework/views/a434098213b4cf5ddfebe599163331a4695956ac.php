<?php if(Session::has('flash_message')): ?>
  	<div style="font-size: 18px;font-style: italic;margin-top:15px;font-weight: bold;" class="alert alert-<?php echo e(session('status_color')); ?>">
  		<span class="fa fa-check-square-o"></span><em> <?php echo session('flash_message'); ?></em>
  	</div>
<?php endif; ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/common/message.blade.php ENDPATH**/ ?>