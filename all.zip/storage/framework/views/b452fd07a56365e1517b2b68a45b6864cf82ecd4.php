<?php $__env->startSection('title', __('supplier.title')); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="icon-list"></i> <?php echo e(__('supplier.title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"><?php echo e(__('supplier.title')); ?></li>
  </ol>
</section>
<!-- Main content -->
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="<?php echo e(url('supplier/create')); ?>" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> <b><?php echo e(__('same.add_new')); ?></b></a> <a href="<?php echo e(url('supplier')); ?>" class="btn btn-warning btn-sm"><i class="fa fa-refresh"></i> <b><?php echo e(__('same.refresh')); ?></b></a> </div>
    <div class="box-body">
      <div class="form-group"> <?php echo e(Form::open(array('url'=>['search-supplier'],'method'=>'GET'))); ?>

        <div class="row col-md-4">
          <div class="pull-left">
            <input name="search_supplier" value="<?php echo e((isset($search_supplier))?$search_supplier:''); ?>" class="form-control supplier-search" placeholder="<?php echo e(__('supplier.search_by')); ?>" type="text" required>
          </div>
          <div class="pull-left">&nbsp;
            <button class="btn btn-default btn-sm" type="submit"><?php echo e(__('same.search')); ?></button>
          </div>
        </div>
        <?php echo Form::close(); ?>

        <div class="clearfix"></div>
      </div>
      <div class="table_scroll">
        <table class="table table-bordered table-striped table-responsive">
          	<th><?php echo e(__('supplier.image')); ?></th>
            <th><?php echo e(__('supplier.supplier_name')); ?></th>
            <th><?php echo e(__('supplier.company_name')); ?></th>
            <th><?php echo e(__('supplier.phone_number')); ?></th>
            <th><?php echo e(__('supplier.email')); ?></th>
            <th><?php echo e(__('same.action')); ?></th>
          <tbody>
          
          <?php if(isset($alldata) && count($alldata)<1): ?>
          <tr>
            <td colspan="6" align="center"><?php echo e(__('same.empty_row')); ?></td>
          </tr>
          <?php else: ?>
          
          <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr> <?php if($data->profile_image): ?>
            <td> <?php if(file_exists('storage/app/public/uploads/suppliers/'.$data->profile_image)): ?> <img src='<?php echo e(asset("storage/app/public/uploads/suppliers/$data->profile_image")); ?>' class="img-thumbnail" width="40px"> <?php else: ?> <img src='<?php echo e(asset("public/custom/img/photo.png")); ?>' width="40px" class="img-thumbnail"> <?php endif; ?> </td>
            <?php else: ?>
            <td><img src='<?php echo e(asset("public/custom/img/photo.png")); ?>' width="40px" class="img-thumbnail"> </td>
            <?php endif; ?>
            <td><?php echo e($data->name); ?></td>
            <td><?php echo e($data->company_name); ?></td>
            <td><?php echo e($data->phn_number); ?></td>
            <td><?php echo e($data->mail_address); ?></td>
            <td><div class="form-inline">
                <div class = "input-group"> <a href="<?php echo e(route('supplier.edit', $data->id)); ?>" class="btn btn-success btn-xs" title="<?php echo e(__('same.edit')); ?>"><i class="icon-pencil"></i></a> </div>
                <div class = "input-group"> <?php echo e(Form::open(array('route'=>['supplier.destroy',$data->id],'method'=>'DELETE'))); ?>

                  <button type="submit" confirm="<?php echo e(__('same.delete_confirm')); ?>" class="btn btn-danger btn-xs confirm" title="<?php echo e(__('same.delete')); ?>"><i class="icon-trash"></i></button>
                  <?php echo Form::close(); ?> </div>
              </div></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          </tbody>
          
        </table>
        <div align="center"><?php echo e($alldata->render()); ?></div>
      </div>
    </div>
    <!-- /.box-body -->
    <div class="box-footer"> </div>
    <!-- /.box-footer-->
  </div>
  <!-- /.box -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/supplier/supplierList.blade.php ENDPATH**/ ?>