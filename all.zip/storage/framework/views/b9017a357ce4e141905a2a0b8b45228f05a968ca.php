<?php $__env->startSection('title', __('manage_cow.title')); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1><i class="icon-list"></i> <?php echo e(__('manage_cow.title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"><?php echo e(__('manage_cow.title')); ?></li>
  </ol>
</section>
<section class="content"> <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="<?php echo e(url('animal/create')); ?>" class="btn btn-success btn-sm" data-toggle="modal"> <i class="fa fa-plus-square"></i> <b><?php echo e(__('same.add_new')); ?></b> </a> <a href="<?php echo e(URL::to('animal')); ?>" class="btn btn-warning btn-sm"> <i class="fa fa-refresh"></i> <b><?php echo e(__('same.refresh')); ?></b> </a> </div>
    <div class="box-body">
      <div class="row">
        <div class="col-sm-12">
          <div class="form-group">
            <div class="table-responsive">
              <table class="table table-bordered table-striped table-responsive">
                <thead>
                  <tr>
                    <th><?php echo e(__('manage_cow.id')); ?></th>
                    <th><?php echo e(__('manage_cow.image')); ?></th>
                    <th><?php echo e(__('manage_cow.gender')); ?></th>
                    <th><?php echo e(__('manage_cow.animal_type')); ?></th>
                    <th><?php echo e(__('manage_cow.buy_date')); ?></th>
                    <th><?php echo e(__('manage_cow.buying_price')); ?></th>
                    <th><?php echo e(__('manage_cow.pregnant_status')); ?></th>
                    <th><?php echo e(__('manage_cow.milk_per_day')); ?></th>
                    <th><?php echo e(__('manage_cow.animal_status')); ?></th>
                    <th><?php echo e(__('same.action')); ?></th>
                  </tr>
                </thead>
                <tbody>
                
                <?php $__currentLoopData = $all_animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><label class="label label-default lblfarm">000<?php echo e($animals->id); ?></label></td>
                  <td> <?php if($animals->pictures !=''): ?>
                    <?php if(file_exists('storage/app/public/uploads/animal/'.explode('_', $animals->pictures)[0])): ?> <img src='<?php echo e(asset("storage/app/public/uploads/animal")); ?>/<?php echo e(explode("_", $animals->pictures)[0]); ?>' class="img-thumbnail" width="50px"> <?php else: ?> <img src='<?php echo e(asset("public/custom/img/noImage.jpg")); ?>' class="img-circle" width="60px"> <?php endif; ?>
                    <?php else: ?> <img src='<?php echo e(asset("public/custom/img/noImage.jpg")); ?>' class="img-circle" width="60px"> <?php endif; ?>
                    <!-- Modal Start -->
                    <div class="modal fade" id="view<?php echo e($animals->id); ?>" tabindex="-1" role="dialog">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title"><i class="fa fa-info-circle edit-color"></i> <?php echo e(__('manage_cow.animal_details')); ?></h4>
                          </div>
                          <div class="modal-body">
                            <table class="table table-bordered table-striped table-responsive">
                              <tbody>
                                <tr>
                                  <td><?php echo e(__('manage_cow.stall_no')); ?></td>
                                  <td> <?php if(isset($animals->animal_shed_object->shed_number)): ?>
                                    <?php echo e($animals->animal_shed_object->shed_number); ?>

                                    <?php endif; ?> </td>
                                </tr>
                                <tr>
                                  <td><?php echo e(__('manage_cow.dob')); ?></td>
                                  <td><?php echo e(Carbon\Carbon::parse($animals->DOB)->format('m/d/Y')); ?></td>
                                </tr>
                                <tr>
                                  <td><?php echo e(__('manage_cow.age')); ?></td>
                                  <td><?php echo e($animals->age); ?> <?php echo e(__('manage_cow.days_or')); ?> <?php echo number_format((float)$animals->age / 30,2,".","."); ?> <?php echo e(__('manage_cow.month')); ?></td>
                                </tr>
                                <tr>
                                  <td><?php echo e(__('manage_cow.weight')); ?></td>
                                  <td><?php echo e($animals->weight); ?> KG</td>
                                </tr>
                                <tr>
                                  <td><?php echo e(__('manage_cow.height')); ?></td>
                                  <td><?php echo e($animals->height); ?> Inch</td>
                                </tr>
                                <tr>
                                  <td><?php echo e(__('manage_cow.color')); ?></td>
                                  <td> <?php if(isset($animals->animal_color_object->color_name)): ?>
                                    <?php echo e($animals->animal_color_object->color_name); ?>

                                    <?php endif; ?> </td>
                                </tr>
                                <tr>
                                  <td><?php echo e(__('manage_cow.nop')); ?></td>
                                  <td><?php echo e($animals->before_no_of_pregnant); ?></td>
                                </tr>
                                <tr>
                                  <td><?php echo e(__('manage_cow.pregnancy_time')); ?></td>
                                  <td> <?php if(!empty($animals->pregnancy_time)): ?>
                                    <?php echo e(date('M d, Y', strtotime($animals->pregnancy_time))); ?>

                                    <?php endif; ?> </td>
                                </tr>
                                <tr>
                                  <td><?php echo e(__('manage_cow.buy_form')); ?></td>
                                  <td><?php echo e($animals->buy_from); ?></td>
                                </tr>
                                <tr>
                                  <td><?php echo e(__('manage_cow.previous_vaccine_done')); ?></td>
                                  <td><?php echo e($animals->previous_vaccine_done); ?></td>
                                </tr>
                                <tr>
                                  <td><?php echo e(__('manage_cow.note')); ?></td>
                                  <td><?php echo e($animals->note); ?></td>
                                </tr>
                                <tr>
                                  <td><?php echo e(__('manage_cow.created_by')); ?></td>
                                  <td><?php echo e($animals->name); ?> <b>(<?php echo e($animals->user_type); ?>)</b></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <div class="modal-footer"></div>
                        </div>
                        <!-- /.modal-content -->
                      </div>
                      <!-- /.modal-dialog -->
                    </div>
                    <!-- /.modal -->
                  </td>
                  <td><?php echo e($animals->gender); ?></td>
                  <td> <?php if(isset($animals->animal_animalType_object->type_name)): ?>
                    <label class="label label-default lblfarm"><?php echo e($animals->animal_animalType_object->type_name); ?></label>
                    <?php endif; ?> </td>
                  <td> <?php if(!empty($animals->buy_date)): ?>
                    <?php echo e(date('M d, Y', strtotime($animals->buy_date))); ?>

                    <?php endif; ?> </td>
                  <td><?php echo e(App\Library\farm::currency($animals->buying_price)); ?></td>
                  <td> <?php if($animals->pregnant_status==0): ?>
                    <label class="label label-warning lblfarm"><?php echo e(__('manage_cow.not_pregnant')); ?></label>
                    <?php else: ?>
                    <label class="label label-success lblfarm"><?php echo e(__('manage_cow.pregnant')); ?></label>
                    <?php endif; ?> </td>
                  <td><?php echo e($animals->milk_ltr_per_day); ?></td>
                  <td> <?php if((bool)$animals->sale_status): ?>
                    <label class="label label-warning lblfarm"><?php echo e(__('manage_cow.sold')); ?></label>
                    <?php else: ?>
                    <label class="label label-success lblfarm"><?php echo e(__('manage_cow.available')); ?></label>
                    <?php endif; ?> </td>
                  <td><div class="form-inline">
                      <div class = "input-group"> <a href="#view<?php echo e($animals->id); ?>" class="btn btn-primary btn-xs" data-toggle="modal" title="<?php echo e(__('same.view')); ?>"><i class="icon-eye"></i></a> </div>
                      <div class = "input-group"> <a href="<?php echo e(route('animal.edit', $animals->id)); ?>" class="btn btn-success btn-xs" title="<?php echo e(__('same.edit')); ?>"><i class="icon-pencil"></i></a> </div>
                      <div class = "input-group"> <?php echo e(Form::open(array('route'=>['animal.destroy',$animals->id],'method'=>'DELETE'))); ?>

                        <button type="submit" confirm="<?php echo e(__('same.delete_confirm')); ?>" class="btn btn-danger btn-xs confirm" title="<?php echo e(__('same.delete')); ?>"><i class="icon-trash"></i></button>
                        <?php echo Form::close(); ?> </div>
                    </div></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <div class="col-md-12" align="center"> <?php echo e($all_animals->render()); ?> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box-footer"> </div>
  </div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/animal/animalList.blade.php ENDPATH**/ ?>