<?php $__env->startSection('title', __('cow_sale.title')); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1><i class="icon-list"></i> <?php echo e(__('cow_sale.title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"><?php echo e(__('cow_sale.title')); ?></li>
  </ol>
</section>
<section class="content"> <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="<?php echo e(url('sale-cow/create')); ?>" class="btn btn-success btn-sm" data-toggle="modal"> <i class="fa fa-plus-square"></i> <b><?php echo e(__('same.add_new')); ?></b> </a> <a href="<?php echo e(URL::to('sale-cow')); ?>" class="btn btn-warning btn-sm"> <i class="fa fa-refresh"></i> <b><?php echo e(__('same.refresh')); ?></b> </a> </div>
    <div class="box-body">
      <div class="row">
        <div class="col-sm-12">
          <div class="form-group">
            <div class="table-responsive">
              <table class="table table-bordered table-striped table-responsive">
                <thead>
                  <tr>
                    <th>#<?php echo e(__('same.invoice')); ?></th>
                    <th><?php echo e(__('cow_sale.date')); ?></th>
                    <th><?php echo e(__('cow_sale.customer_name')); ?></th>
                    <th><?php echo e(__('cow_sale.customer_phone')); ?> </th>
                    <th><?php echo e(__('cow_sale.customer_email')); ?> </th>
                    <th><?php echo e(__('cow_sale.address')); ?> </th>
                    <th><?php echo e(__('cow_sale.total_price')); ?></th>
                    <th><?php echo e(__('cow_sale.total_paid')); ?></th>
                    <th><?php echo e(__('cow_sale.due')); ?></th>
                    <th><?php echo e(__('cow_sale.note')); ?></th>
                    <th><?php echo e(__('same.action')); ?></th>
                  </tr>
                </thead>
                <tbody>
                
                <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saleinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
				  	$total_paid = $saleinfo->collectPayments()->sum('pay_amount');
			 		$total_due = (float)$saleinfo->total_price - (float)$total_paid;
				  ?>
                <tr>
                  <td><label class="label label-default lblfarm">000<?php echo e($saleinfo->id); ?></label></td>
                  <td><?php echo e(date('M d, Y', strtotime($saleinfo->date))); ?></td>
                  <td><?php echo e($saleinfo->customer_name); ?></td>
                  <td><?php echo e($saleinfo->customer_number); ?></td>
                  <td><?php echo e($saleinfo->email); ?></td>
                  <td><?php echo e($saleinfo->address); ?></td>
                  <td><label class="label label-success lblfarm"><?php echo e(App\Library\farm::currency($saleinfo->total_price)); ?></label></td>
                  <td><label class="label label-warning lblfarm"><?php echo e(App\Library\farm::currency($total_paid)); ?></label></td>
                  <td><label class="label label-danger lblfarm"><?php echo e(App\Library\farm::currency($total_due)); ?></label></td>
                  <td><a href="#view<?php echo e($saleinfo->id); ?>" class="btn btn-info btn-xs" data-toggle="modal"> <i class="fa fa-info-circle"></i> </a>
                    <!-- Modal Start -->
                    <div class="modal fade" id="view<?php echo e($saleinfo->id); ?>" tabindex="-1" role="dialog">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title"><i class="fa fa-info-circle edit-color"></i> <?php echo e(__('cow_sale.note')); ?></h4>
                          </div>
                          <div class="modal-body">
                            <p class="text-equal"><?php echo e($saleinfo->note); ?></p>
                          </div>
                          <div class="modal-footer"></div>
                        </div>
                        <!-- /.modal-content -->
                      </div>
                      <!-- /.modal-dialog -->
                    </div>
                    <!-- /.modal -->
                  </td>
                  <td><!-- Modal Start -->
                    <div class="modal fade" id="cow<?php echo e($saleinfo->id); ?>" tabindex="-1" role="dialog">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title"><i class="fa fa-info-circle edit-color"></i> <?php echo e(__('cow_sale.cow_details')); ?></h4>
                          </div>
                          <div class="modal-body">
                            <?php  $cowInfo = DB::table('cow_sale_dtls')->where('sale_id', $saleinfo->id)->get(); ?>
                            <table class="table table-bordered table-striped table-responsive">
                              	<th><?php echo e(__('cow_sale.image')); ?></th>
                                <th><?php echo e(__('cow_sale.cow_no')); ?></th>
                                <th><?php echo e(__('cow_sale.stall_no')); ?></th>
                                <th><?php echo e(__('cow_sale.gender')); ?></th>
                                <th><?php echo e(__('cow_sale.weight')); ?> (<?php echo e(__('same.kg')); ?>)</th>
                                <th><?php echo e(__('cow_sale.height')); ?> (<?php echo e(__('same.inch')); ?>)</th>
                              <tbody>
                                <?php if(!empty($cowInfo)) { ?>
                              <?php $__currentLoopData = $cowInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cowInfoData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php  
									  if($cowInfoData->cow_type==1) {
                                        $dataInfo = DB::table('animals')->leftJoin('sheds', 'sheds.id', 'animals.shade_no')
                                        ->where('animals.id', $cowInfoData->cow_id)
                                        ->select('animals.*', 'sheds.shed_number')->first();
                                      } else {
                                          $dataInfo = DB::table('calf')->leftJoin('sheds', 'sheds.id', 'calf.shade_no')
                                          ->where('calf.id', $cowInfoData->cow_id)
                                          ->select('calf.*', 'sheds.shed_number')->first();
                                      }
                                    ?>
                              <tr>
                                <td> <?php if($dataInfo->pictures !=''): ?>
                                  <?php if(file_exists('storage/app/public/uploads/animal/'.explode('_', $dataInfo->pictures)[0])): ?> <img src='<?php echo e(asset("storage/app/public/uploads/animal")); ?>/<?php echo e(explode("_", $dataInfo->pictures)[0]); ?>' class="img-thumbnail" width="100px"> <?php else: ?> <img src='<?php echo e(asset("public/custom/img/noImage.jpg")); ?>' class="img-thumbnail" width="100px"> <?php endif; ?>
                                  <?php else: ?> <img src='<?php echo e(asset("public/custom/img/noImage.jpg")); ?>' class="img-thumbnail" width="100px"> <?php endif; ?> </td>
                                <td>000 <?php echo e($dataInfo->id); ?></td>
                                <td><?php echo e($dataInfo->shed_number); ?></td>
                                <td><?php echo e($dataInfo->gender); ?></td>
                                <td><?php echo e($dataInfo->weight); ?></td>
                                <td><?php echo e($dataInfo->height); ?></td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php } ?>
                              </tbody>
                              
                            </table>
                          </div>
                          <div class="modal-footer"></div>
                        </div>
                        <!-- /.modal-content -->
                      </div>
                      <!-- /.modal-dialog -->
                    </div>
                    <!-- /.modal -->
                    <div class="form-inline">
                      <div class = "input-group"> <a target="_blank" href="<?php echo e(URL::to('sale-invoice')); ?>/<?php echo e($saleinfo->id); ?>" class="btn btn-default btn-xs" title="<?php echo e(__('same.invoice')); ?>"><i class="icon-doc"></i></a> </div>
                      <div class = "input-group"> <a href="#cow<?php echo e($saleinfo->id); ?>" class="btn btn-primary btn-xs" data-toggle="modal" title="<?php echo e(__('same.view')); ?>"><i class="icon-eye"></i></a> </div>
                      <div class = "input-group"> <a href="<?php echo e(route('sale-cow.edit', $saleinfo->id)); ?>" class="btn btn-success btn-xs" title="<?php echo e(__('same.edit')); ?>"><i class="icon-pencil"></i></a> </div>
                      <div class = "input-group"> <?php echo e(Form::open(array('route'=>['sale-cow.destroy',$saleinfo->id],'method'=>'DELETE'))); ?>

                        <button type="submit" confirm="Are you sure you want to delete this information ?" class="btn btn-danger btn-xs confirm" title="<?php echo e(__('same.delete')); ?>"><i class="icon-trash"></i></button>
                        <?php echo Form::close(); ?> </div>
                    </div></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
              </table>
              <div class="col-md-12" align="center"> <?php echo e($allData->render()); ?> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box-footer"> </div>
  </div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/sale-cow/list.blade.php ENDPATH**/ ?>