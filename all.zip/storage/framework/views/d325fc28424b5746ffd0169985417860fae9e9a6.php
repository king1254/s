
<?php $__env->startSection('title', __('stall.title')); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="icon-list"></i> <?php echo e(__('stall.title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"><?php echo e(__('stall.title')); ?></li>
  </ol>
</section>
<!-- Main content -->
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="#saveModal" data-toggle="modal" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> <b><?php echo e(__('same.add_new')); ?></b></a> <a href="<?php echo e(url('sheds')); ?>" class="btn btn-warning btn-sm"><i class="fa fa-refresh"></i> <b><?php echo e(__('same.refresh')); ?></b></a> </div>
    <div class="box-body">
      <div class="form-group">
        <div class="clearfix"></div>
      </div>
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading"><i class="fa fa-list"></i> <?php echo e(__('stall.all_stall_list')); ?></div>
          <div class="panel-body">
            <div class="table_scroll">
            <table class="table table-bordered table-striped table-responsive table-hover">
              <th>#</th>
                <th><?php echo e(__('stall.stall_no')); ?></th>
                <th><?php echo e(__('stall.status')); ?></th>
                <th><?php echo e(__('stall.details')); ?></th>
                <th><?php echo e(__('same.action')); ?></th>
              <tbody>
                <?php                           
                      $number = 1;
                      $numElementsPerPage = 15; // How many elements per page
                      $pageNumber = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                      $currentNumber = ($pageNumber - 1) * $numElementsPerPage + $number;
                      $rowCount = 0;
                    ?>
              <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $rowCount++; ?>
              <tr>
                <td><label class="label label-success"><?php echo e($currentNumber++); ?></label>
                </td>
                <td><?php echo e($data->shed_number); ?></td>
                <td><?php if($data->status == 1): ?>
                  <label class="label label-danger lblfarm"><?php echo e(__('stall.booked')); ?></label>
                  <?php else: ?>
                  <label class="label label-success lblfarm"><?php echo e(__('stall.available')); ?></label>
                  <?php endif; ?></td>
                <td><?php echo e($data->description); ?></td>
                <td><div class="form-inline">
                    <div class = "input-group"> <a href="#editModal<?php echo e($data->id); ?>" data-toggle="modal" class="btn btn-success btn-xs" title="<?php echo e(__('same.edit')); ?>"><i class="icon-pencil"></i></a> </div>
                    <div class = "input-group"> <?php echo e(Form::open(array('route'=>['sheds.destroy',$data->id],'method'=>'DELETE'))); ?>

                      <button type="submit" confirm="<?php echo e(__('same.delete_confirm')); ?>" class="btn btn-danger btn-xs confirm" title="<?php echo e(__('same.delete')); ?>"><i class="icon-trash"></i></button>
                      <?php echo Form::close(); ?> </div>
                  </div>
                  <!-- Modal -->
                  <div class="modal fade" id="editModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog">
                    <div class="modal-dialog modal-md">
                      <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          <h4 class="modal-title"><i class="fa fa-edit edit-color"></i> <?php echo e(__('stall.edit_stall')); ?></h4>
                        </div>
                        <?php echo Form::open(array('route' =>['sheds.update', $data->id],'class'=>'form-horizontal','method'=>'PUT')); ?>

                        <div class="modal-body">
                          <div class="form-group">
                            <div class="col-md-12"> <?php echo e(Form::label('shed_number', __('stall.stall_no'))); ?> <span class="validate">*</span> :
                              <input type="text" class="form-control" value="<?php echo e($data->shed_number); ?>" name="shed_number" placeholder="Stall Number | Name" required>
                            </div>
                            <?php echo e(Form::hidden('id',$data->id)); ?> </div>
                          <div class="form-group">
                            <div class="col-md-12"> <?php echo e(Form::label('description', __('stall.details'))); ?> :
                              <textarea class="form-control" name="description"><?php echo e($data->description); ?></textarea>
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-md-6"> </div>
                            <div class="col-md-6">
                              <div class="row">
                                <div class="col-md-12" align="right">
                                  <button type="button" class="btn btn-default btn-sm" data-dismiss="modal"><?php echo e(__('same.close')); ?></button>
								  <?php echo e(Form::submit(__('same.update'),array('class'=>'btn btn-warning btn-sm'))); ?>

                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer"> </div>
                      <?php echo Form::close(); ?> </div>
                    <!-- /.modal-content -->
                  </div>
                  <!-- /.modal-dialog -->
              </div>
              
              <!-- /.modal -->
              </td>
              
              </tr>
              
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if($rowCount==0): ?>
              <tr>
                <td colspan="4" align="center"><h2><?php echo e(__('same.empty_row')); ?></h2></td>
              </tr>
              <?php endif; ?>
              </tbody>
              
            </table>
            <div align="center"><?php echo e($allData->render()); ?></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /.box-body -->
  <div class="box-footer"> </div>
  <!-- /.box-footer-->
  </div>
  <!-- /.box -->
  <!-- Modal -->
  <div class="modal fade" id="saveModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title"><i class="fa fa-plus-square" style="color: green"></i> <?php echo e(__('stall.add_stall')); ?></h4>
        </div>
        <?php echo Form::open(array('route' =>['sheds.store'],'class'=>'form-horizontal','method'=>'POST')); ?>

        <div class="modal-body">
          <div class="form-group">
            <div class="col-md-12"> <?php echo e(Form::label('shed_number', __('stall.stall_no'))); ?> <span class="validate">*</span> :
              <input type="text" class="form-control" id="shed_number" value="" name="shed_number" placeholder="Stall Number | Name" required>
            </div>
          </div>
          <div class="form-group">
            <div class="col-md-12"> <?php echo e(Form::label('description', __('stall.details'))); ?> :
              <textarea class="form-control" name="description"></textarea>
            </div>
          </div>
          <div class="form-group">
            <div class="col-md-6"> </div>
            <div class="col-md-6">
              <div class="row">
                <div class="col-md-12" align="right">
                  <button type="button" class="btn btn-default btn-sm" data-dismiss="modal"><?php echo e(__('same.close')); ?></button>
				  <?php echo e(Form::submit(__('same.save'),array('class'=>'btn btn-success btn-sm'))); ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer"> </div>
      <?php echo Form::close(); ?> </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vflhvhga/hadirinn/resources/views/sheds/index.blade.php ENDPATH**/ ?>