<?php $__env->startSection('title', __('sale_milk.invoice_title')); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1><i class="icon-docs"></i> <?php echo e(__('sale_milk.invoice_title')); ?></h1>
  <ol class="breadcrumb">
    <li><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></li>
    <li class="active"><?php echo e(__('sale_milk.invoice')); ?></li>
  </ol>
</section>
<?php 
$configuration_data = \App\Library\farm::get_system_configuration('system_config'); 
$branchFullData = DB::table('branchs')->where('id', Session::get('branch_id'))->first();
?>
<section class="content"> <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="<?php echo e(URL::to('sale-milk')); ?>" class="btn btn-default btn-sm"><i class="icon-list"></i> <?php echo e(__('same.back')); ?></a> <a href="javascript:;" class="printReport btn btn-default btn-sm"><i class="icon-printer"></i> <?php echo e(__('same.print')); ?></a> </div>
    <div class="box-body">
      <div class="container" id="print-box">
        <div class="card">
          <div class="card-header"> <?php echo e(__('sale_milk.invoice')); ?> <strong> #000<?php echo e($single_data->id); ?></strong> <span class="float-right"> <strong><?php echo e(__('sale_milk.issue_date')); ?> :</strong> <?php echo e(Carbon\Carbon::parse($single_data->date)->format('d/m/Y')); ?></span> </div>
          <div class="card-body">
            <div class="row mb-4">
              <div class="col-sm-8">
                <h6 class="mb-3"><?php echo e(__('sale_milk.form')); ?> :</h6>
                <div> <strong><?php if(!empty($configuration_data) && !empty($configuration_data->topTitle)): ?><?php echo e($configuration_data->topTitle); ?><?php endif; ?></strong> </div>
                <div><?php if(!empty($branchFullData->branch_name)): ?><?php echo e($branchFullData->branch_name); ?><?php endif; ?></div>
                <div><?php if(!empty($branchFullData->branch_address)): ?><?php echo e($branchFullData->branch_address); ?><?php endif; ?></div>
                <div>Email: <?php if(!empty($branchFullData->phone_number)): ?><?php echo e($branchFullData->phone_number); ?><?php endif; ?></div>
                <div>Phone: <?php if(!empty($branchFullData->email)): ?><?php echo e($branchFullData->email); ?><?php endif; ?></div>
              </div>
              <div class="col-sm-4">
                <h6 class="mb-3"><?php echo e(__('sale_milk.to')); ?> :</h6>
                <div> <strong><?php if(!empty($single_data) && !empty($single_data->name)): ?><?php echo e($single_data->name); ?><?php endif; ?></strong> </div>
                <div>Phone: <?php if(!empty($single_data) && !empty($single_data->contact)): ?><?php echo e($single_data->contact); ?><?php endif; ?></div>
                <div>Email: <?php if(!empty($single_data) && !empty($single_data->email)): ?><?php echo e($single_data->email); ?><?php endif; ?></div>
                <div>Address: <?php if(!empty($single_data) && !empty($single_data->address)): ?><?php echo e($single_data->address); ?><?php endif; ?></div>
              </div>
            </div>
            <div class="table-responsive-sm overflowauto">
              <table class="table table-striped invoice_table">
                <thead>
                  <tr>
                    <th class="center"><?php echo e(__('sale_milk.account_no')); ?></th>
                    <th><?php echo e(__('sale_milk.description')); ?></th>
                    <th><?php echo e(__('sale_milk.liter')); ?></th>
                    <th><?php echo e(__('sale_milk.price')); ?></th>
                    <th class="right"><?php echo e(__('sale_milk.total')); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="center"><?php echo e($single_data->milk_account_number); ?></td>
                    <td class="left"><?php echo e(__('sale_milk.milk_sale')); ?></td>
                    <td class="center"><?php echo e($single_data->litter); ?></td>
                    <td class="right"><?php echo e(App\Library\farm::currency($single_data->rate)); ?></td>
                    <td class="right"><?php echo e(App\Library\farm::currency($single_data->total_amount )); ?></td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td align="right"><strong><?php echo e(__('sale_milk.total')); ?> : </strong> </td>
                    <td align="left"><?php echo e(App\Library\farm::currency($single_data->total_amount)); ?></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td align="right"><strong><?php echo e(__('sale_milk.paid')); ?> : </strong> </td>
                    <td align="left"><?php echo e(App\Library\farm::currency($sale_paid_amount)); ?></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td align="right"><strong><?php echo e(__('sale_milk.due')); ?> : </strong> </td>
                    <td align="left"><?php echo e(App\Library\farm::currency($sale_due_amount)); ?></td>
                  </tr>
                </tfoot>
              </table>
            </div>
            <div class="row"> <?php if(!empty($sale_due_amount) && (float)$sale_due_amount > 0): ?>
              <div class="col-lg-8 paymentsttausbox">
                <div><img class="payment_status_icon" src="<?php echo e(asset("public/common/due.png")); ?>" /></div>
              </div>
              <?php else: ?>
              <div class="col-lg-8"><img class="payment_status_icon" src="<?php echo e(asset("public/common/paid.png")); ?>" /></div>
              <?php endif; ?> </div>
            <br/>
            <br/>
          </div>
        </div>
      </div>
      <div class="box-footer"> </div>
    </div>
  </div>
</section>
<?php echo Html::style('public/custom/css/print.css'); ?>

<input type="hidden" id="print_url_1" value='<?php echo Html::style("public/custom/css/bootstrap.min.css"); ?>' />
<input type="hidden" id="print_url_2" value='<?php echo Html::style("public/custom/css/print.css"); ?>' />
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/invoice/milk-sale.blade.php ENDPATH**/ ?>