<?php $__env->startSection('title', __('sale_milk.title')); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="icon-list"></i> <?php echo e(__('sale_milk.title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"><?php echo e(__('sale_milk.title')); ?></li>
  </ol>
</section>
<!-- Main content -->
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="#saveModal" data-toggle="modal" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> <b> <?php echo e(__('sale_milk.sale_new')); ?></b></a> <a href="<?php echo e(url('sale-milk')); ?>" class="btn btn-warning  btn-sm"><i class="fa fa-refresh"></i> <b><?php echo e(__('same.refresh')); ?></b></a> </div>
    <div class="box-body">
      <div class="form-group">
        <div class="clearfix"></div>
      </div>
      <div class="table_scroll">
        <table class="table table-bordered table-striped table-responsive">
          <th>#</th>
            <th><?php echo e(__('sale_milk.invoice')); ?></th>
            <th><?php echo e(__('sale_milk.date')); ?></th>
            <th><?php echo e(__('sale_milk.account_no')); ?></th>
            <th><?php echo e(__('sale_milk.name')); ?></th>
            <th><?php echo e(__('sale_milk.contact')); ?></th>
            <th><?php echo e(__('sale_milk.email')); ?></th>
            <th><?php echo e(__('sale_milk.liter')); ?></th>
            <th><?php echo e(__('sale_milk.price')); ?></th>
            <th><?php echo e(__('sale_milk.total')); ?></th>
            <th><?php echo e(__('sale_milk.paid')); ?></th>
            <th><?php echo e(__('sale_milk.due')); ?></th>
            <th><?php echo e(__('sale_milk.sold_by')); ?></th>
            <th><?php echo e(__('same.action')); ?></th>
          <tbody>
            <?php                           
              $number = 1;
              $numElementsPerPage = 40; // How many elements per page
              $pageNumber = isset($_GET['page']) ? (int)$_GET['page'] : 1;
              $currentNumber = ($pageNumber - 1) * $numElementsPerPage + $number;
              $countRow = 0;
            ?>
          <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $countRow++; ?>
          <?php 		  
			  $total_paid = $data->collectPayments()->sum('pay_amount');
			  $total_due = (float)$data->total_amount - (float)$total_paid;
		  ?>
          <tr>
            <td><label class="label label-success"><?php echo e($currentNumber++); ?></label>
            </td>
            <td><label class="label label-default lblfarm">000<?php echo e($data->id); ?></label></td>
            <td><?php echo e(date('m/d/Y',strtotime($data->date))); ?></td>
            <td><?php echo e($data->milk_account_number); ?></td>
            <td><?php echo e($data->name); ?></td>
            <td><?php echo e($data->contact); ?></td>
            <td><?php echo e($data->email); ?></td>
            <td><?php echo e($data->litter); ?></td>
            <td><?php echo e(App\Library\farm::currency($data->rate)); ?></td>
            <td>
            <label class="label label-success lblfarm">
            <?php echo e(App\Library\farm::currency($data->total_amount)); ?>

            <label>
            </td>
            <td><label class="label label-warning lblfarm"><?php echo e(App\Library\farm::currency($total_paid)); ?></label></td>
            <td><label class="label label-danger lblfarm"><?php echo e(App\Library\farm::currency($total_due)); ?></label></td>
            <td><?php echo e($data->sold_by); ?> <b>(<?php echo e($data->user_type); ?>)</b></td>
            <td><div class="form-inline">
                <div class = "input-group"> <a target="_blank" href="<?php echo e(URL::to('sale-milk-invoice')); ?>/<?php echo e($data->id); ?>" class="btn btn-default btn-xs" title="<?php echo e(__('same.invoice')); ?>"><i class="icon-doc"></i></a> </div>
                <div class = "input-group"> <a href="#editModal<?php echo e($data->id); ?>" data-toggle="modal" class="btn btn-success btn-xs" title="<?php echo e(__('same.edit')); ?>"><i class="icon-pencil"></i></a> </div>
                <div class = "input-group"> <?php echo e(Form::open(array('route'=>['sale-milk.destroy',$data->id],'method'=>'DELETE'))); ?>

                  <button type="submit" confirm="<?php echo e(__('same.delete_confirm')); ?>" class="btn btn-danger btn-xs confirm" title="<?php echo e(__('same.delete')); ?>"><i class="icon-trash"></i></button>
                  <?php echo Form::close(); ?> </div>
              </div>
              <!-- Modal -->
              <div class="modal fade" id="editModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-md">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                      <h4 class="modal-title"><i class="fa fa-edit edit-color"></i> <?php echo e(__('sale_milk.edit_information')); ?></h4>
                    </div>
                    <?php echo Form::open(array('route' =>['sale-milk.update', $data->id],'class'=>'form-horizontal','method'=>'PUT')); ?>

                    <div class="modal-body">
                      <div class="row">
                        <div class="col-md-12">
                          <div class="form-group">
                            <div class="col-md-6">
                              <label for="milk_account_number"><?php echo e(__('sale_milk.account_number')); ?> <span class="validate">*</span> : </label>
                              <select name="milk_account_number" id="milk_account_number_<?php echo e($data->id); ?>" class="form-control" onchange="calculateSaleMilkSaleMilk('<?php echo e($data->id); ?>', this)" required>
                                <option value=""><?php echo e(__('same.select')); ?></option>
                                
                                 	<?php $__currentLoopData = $milkData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $milkDataInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <option value="<?php echo e($milkDataInfo->account_number); ?>" data-price="<?php echo e($milkDataInfo->liter_price); ?>" <?php echo e($milkDataInfo->account_number==$data->milk_account_number?'selected':''); ?>>
                                <?php echo e($milkDataInfo->account_number); ?> [ Date - <?php echo e(date('M d, Y', strtotime($milkDataInfo->date))); ?>] [Collected Milk <?php echo e($milkDataInfo->liter); ?> Liter] </option>
                                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                              </select>
                            </div>
                            <div class="col-md-6">
                              <label for="supplier_id"><?php echo e(__('sale_milk.supplier')); ?> : </label>
                              <select name="supplier_id" id="supplier_id_<?php echo e($data->id); ?>" class="form-control" onchange="loadSupplierData(<?php echo e($data->id); ?>)">
                                <option value=""><?php echo e(__('same.select')); ?></option>
                                
                                     <?php $__currentLoopData = $supplierArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplierData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <option value="<?php echo e($supplierData->id); ?>" data-name="<?php echo e($supplierData->name); ?>" data-email="<?php echo e($supplierData->mail_address); ?>"data-phn_number="<?php echo e($supplierData->phn_number); ?>" data-address="<?php echo e($supplierData->present_address); ?>" <?php echo e($supplierData->id==$data->supplier_id?'selected':''); ?>>
                                <?php echo e($supplierData->name); ?> [ Company: <?php echo e($supplierData->company_name); ?>] </option>
                                
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                              </select>
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-md-6">
                              <label for="name"><?php echo e(__('sale_milk.name')); ?> <span class="validate">*</span> : </label>
                              <input type="text" name="name" id="name_<?php echo e($data->id); ?>" class="form-control" value="<?php echo e($data->name); ?>" required >
                            </div>
                            <div class="col-md-6">
                              <label for="contact"><?php echo e(__('sale_milk.contact')); ?> : </label>
                              <input type="text" name="contact" id="contact_<?php echo e($data->id); ?>" value="<?php echo e($data->contact); ?>" class="form-control" >
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-md-12">
                              <label for="email"><?php echo e(__('sale_milk.email')); ?> <span class="validate">*</span> : </label>
                              <input type="text" name="email" id="email_<?php echo e($data->id); ?>" class="form-control" value="<?php echo e($data->email); ?>" required >
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-md-12">
                              <label for="address"><?php echo e(__('sale_milk.address')); ?> : </label>
                              <textarea name="address" id="address_<?php echo e($data->id); ?>" class="form-control"><?php echo e($data->address); ?></textarea>
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-md-6">
                              <label for="litter"><?php echo e(__('sale_milk.liter')); ?> <span class="validate">*</span> : </label>
                              <input type="text" name="litter" id="liter_<?php echo e($data->id); ?>" value="<?php echo e($data->litter); ?>" onkeyup="calculateSaleMilk('<?php echo e($data->id); ?>')" class="form-control decimal" required >
                            </div>
                            <div class="col-md-6">
                              <label for="rate"><?php echo e(__('sale_milk.price_litre')); ?> : </label>
                              <input type="text" name="rate" id="liter_price_<?php echo e($data->id); ?>" value="<?php echo e($data->rate); ?>" onkeyup="calculateSaleMilk('<?php echo e($data->id); ?>')" class="form-control" required readonly >
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-md-6">
                              <label for="total_amount"><?php echo e(__('sale_milk.total')); ?> : </label>
                              <input type="text" name="total_amount" id="total_<?php echo e($data->id); ?>" value="<?php echo e($data->total_amount); ?>" class="form-control" required readonly>
                            </div>
                            <div class="col-md-6">
                              <label for="paid"><?php echo e(__('sale_milk.paid')); ?> : </label>
                              <input type="text" name="paid" id="paid_<?php echo e($data->id); ?>" value="<?php echo e($data->paid); ?>" onkeyup="calculateSaleMilk('<?php echo e($data->id); ?>')" class="form-control decimal">
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-md-12">
                              <label for="due"><?php echo e(__('sale_milk.due')); ?> <span class="validate">*</span> : </label>
                              <input type="text" name="due" id="due_<?php echo e($data->id); ?>" value="<?php echo e($data->due); ?>" class="form-control" readonly>
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-md-12" align="right">
                              <button type="button" class="btn btn-default btn-sm" data-dismiss="modal"> <?php echo e(__('same.close')); ?> </button>
							  <button type="submit" name="update" class="btn btn-warning btn-sm"> <?php echo e(__('same.update')); ?> </button>
							  </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <?php echo Form::close(); ?> </div>
                  <!-- /.modal-content -->
                  <div class="modal-footer"> </div>
                </div>
                <!-- /.modal-dialog -->
              </div>
              <!-- /.modal -->
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if($countRow==0): ?>
          <tr>
            <td colspan="12" align="center"><h2><?php echo e(__('same.empty_row')); ?></h2></td>
          </tr>
          <?php endif; ?>
          </tbody>
          
        </table>
        <div align="center"><?php echo e($allData->render()); ?></div>
      </div>
    </div>
    <!-- /.box-body -->
    <div class="box-footer"> </div>
    <!-- /.box-footer-->
  </div>
  <!-- /.box -->
  <!-- Modal -->
  <div class="modal fade" id="saveModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title"><i class="fa fa-plus-square color-green"></i> <?php echo e(__('sale_milk.sale_milk')); ?></h4>
        </div>
        <?php echo Form::open(array('route' =>['sale-milk.store'],'class'=>'form-horizontal','method'=>'POST')); ?>

        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <div class="col-md-12">
                  <label for="milk_account_number"><?php echo e(__('sale_milk.account_no')); ?> <span class="validate">*</span> : </label>
                  <select name="milk_account_number" id="milk_account_number_0" class="form-control" onchange="calculateSaleMilk(0, this)" required>
                    <option value=""><?php echo e(__('same.select')); ?></option>
                     <?php $__currentLoopData = $milkData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $milkDataInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($milkDataInfo->account_number); ?>" data-stock="<?php echo e($milkDataInfo->liter); ?>" data-price="<?php echo e($milkDataInfo->liter_price); ?>"> <?php echo e($milkDataInfo->account_number); ?> [ Date - <?php echo e(date('M d, Y', strtotime($milkDataInfo->date))); ?>] [Collected Milk <?php echo e($milkDataInfo->liter); ?> Liter] </option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="panel panel-default" id="view-stock-info">
                <div class="panel-body">
                  <h4><u><b><?php echo e(__('sale_milk.account_information')); ?></b></u></h4>
                  <div class="col-md-12 row">
                    <div class="col-md-6 row" id="milk-in-stock" align="center">
                      <div class="available"><?php echo e(__('sale_milk.available')); ?> : <span></span> <?php echo e(__('sale_milk.liter')); ?></div>
                    </div>
                    <div class="col-md-3 row" id="stock-paid" align="center">
                      <div class="paid"><?php echo e(__('sale_milk.paid')); ?> : <span></span></div>
                    </div>
                    <div class="col-md-3 row" id="stock-due" align="right">
                      <div class="due"><?php echo e(__('sale_milk.due')); ?> : <span></span></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-12">
                  <label for="supplier_id"><?php echo e(__('sale_milk.supplier')); ?> : </label>
                  <select name="supplier_id" id="supplier_id_0" class="form-control" onchange="loadSupplierData(0)">
                    <option value=""><?php echo e(__('same.select')); ?></option>
                            <?php $__currentLoopData = $supplierArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplierData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($supplierData->id); ?>" data-name="<?php echo e($supplierData->name); ?>" data-email="<?php echo e($supplierData->mail_address); ?>" data-phn_number="<?php echo e($supplierData->phn_number); ?>" data-address="<?php echo e($supplierData->present_address); ?>"> <?php echo e($supplierData->name); ?> [ Company: <?php echo e($supplierData->company_name); ?>] </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-6">
                  <label for="name"><?php echo e(__('sale_milk.name')); ?> <span class="validate">*</span> : </label>
                  <input type="text" name="name" id="name_0" class="form-control" required >
                </div>
                <div class="col-md-6">
                  <label for="contact"><?php echo e(__('sale_milk.contact')); ?> : </label>
                  <input type="text" name="contact" id="contact_0" class="form-control" >
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-12">
                  <label for="email"><?php echo e(__('sale_milk.email')); ?> <span class="validate">*</span> : </label>
                  <input type="text" name="email" id="email_0" class="form-control" required >
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-12">
                  <label for="address"><?php echo e(__('sale_milk.address')); ?> : </label>
                  <textarea name="address" id="address_0" class="form-control"></textarea>
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-6">
                  <label for="litter"><?php echo e(__('sale_milk.liter')); ?> <span class="validate">*</span> : </label>
                  <input type="text" name="litter" id="liter_0" onkeyup="calculateSaleMilk(0)" class="form-control decimal" required >
                </div>
                <div class="col-md-6">
                  <label for="rate"><?php echo e(__('sale_milk.price_litre')); ?> : </label>
                  <input type="text" name="rate" id="liter_price_0" onkeyup="calculateSaleMilk(0)" class="form-control" required readonly >
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-6">
                  <label for="total_amount"><?php echo e(__('sale_milk.total')); ?> : </label>
                  <input type="text" name="total_amount" id="total_0" class="form-control" required readonly>
                </div>
                <div class="col-md-6">
                  <label for="paid"><?php echo e(__('sale_milk.paid')); ?> <span class="validate">*</span> : </label>
                  <input type="text" name="paid" id="paid_0" onkeyup="calculateSaleMilk(0)" class="form-control decimal" required>
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-12">
                  <label for="due"><?php echo e(__('sale_milk.due')); ?> : </label>
                  <input type="text" name="due" id="due_0" class="form-control" readonly>
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-12" align="right">
                  <button type="button" class="btn btn-default btn-sm" data-dismiss="modal"> <?php echo e(__('same.close')); ?> </button>
                  <button type="submit" name="save" class="btn btn-success btn-sm"> <?php echo e(__('same.save')); ?> </button>
				  <button type="submit" name="invoice" class="btn btn-warning btn-sm"> <?php echo e(__('sale_milk.generate_invoice')); ?> </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer"> </div>
      <?php echo Form::close(); ?> </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->
  <input type="hidden" id="hdnStockUrl" value="<?php echo e(URL::to('get-stock-status')); ?>" />
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/sale-milk/list.blade.php ENDPATH**/ ?>