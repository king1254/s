<div class="row">
  <div class="col-md-12 ajax-page-bb" align="center">
    <h3><?php echo e(__('cow_monitor.cow_details')); ?></h3>
  </div>
</div>
<div class="row ajax-page-pt15">
<div class="col-md-12">
  <div class="col-md-6"> <?php if(isset($cow_score->new_images) && !empty($cow_score->new_images)): ?>
    <div class="owl-carousel cm-slider"> <?php $__currentLoopData = explode('_', $cow_score->new_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="img-thumbnail"><img src="<?php echo e(asset('storage/app/public/uploads/animal/'.$imageName)); ?>" /></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
    <?php else: ?>
    <div class="owl-carousel cm-slider"> <?php $__currentLoopData = explode('_', $single_data->pictures); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="img-thumbnail"><img src="<?php echo e(asset('storage/app/public/uploads/animal/'.$imageName)); ?>" /></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
    <?php endif; ?> </div>
  <div class="col-md-6 border">
    <table class="table table-bordered table-striped table-responsive">
      <tr>
        <td><b><?php echo e(__('cow_monitor.date_of_birth')); ?></b></td>
        <td><?php echo e((!empty($single_data->DOB))?Carbon\Carbon::parse($single_data->DOB)->format('M d, Y'):''); ?></td>
      </tr>
      <tr>
        <td><b><?php echo e(__('cow_monitor.animal_live_age')); ?></b></td>
        <td><?php echo e((!empty($single_data->age)) ? \App\Library\farm::animalAgeFormat($single_data->DOB) : ''); ?></td>
      </tr>
      <tr>
        <td><b><?php echo e(__('cow_monitor.buy_time_to_current')); ?></b></td>
        <td><?php echo e((!empty($single_data->buy_date)) ? \App\Library\farm::animalAgeFormat($single_data->buy_date) : ''); ?></td>
      </tr>
      <tr>
        <td><b><?php echo e(__('cow_monitor.animal_gender')); ?></b></td>
        <td><?php echo e($single_data->gender); ?></td>
      </tr>
      <tr>
        <td><b><?php echo e(__('cow_monitor.animal_type')); ?></b></td>
        <td><?php echo e((!empty($single_data->type_name)) ? $single_data->type_name : ''); ?></td>
      </tr>
      <tr>
        <td><b><?php echo e(__('cow_monitor.vaccine_status')); ?></b></td>
        <td><?php if(!empty($vaccine_pending)): ?>
          <label class="label label-danger"><?php echo e(__('cow_monitor.pending')); ?></label>
          <?php else: ?>
          <label class="label label-success"><?php echo e(__('cow_monitor.perfect')); ?></label>
          <?php endif; ?></td>
      </tr>
      <?php if(!empty($cow_score->health_score)): ?>
      <tr>
        <td><b><?php echo e(__('cow_monitor.health_status')); ?></b></td>
        <td><?php
						$color = '';
						$message = '';
						$hc = $cow_score->health_score;
						if((int)$hc >= 80){
							$color = 'green';
							$message = __('cow_monitor.good_condition');
						} else if((int)$hc < 80 && (int)$hc > 50){
							$color = 'yellow';
							$message = __('cow_monitor.warning_condition');
						} else if((int)$hc <= 50){
							$color = 'red';
							$message = __('cow_monitor.danger_condition');
						}
					?>
          <div class="progress-group"> <span class="progress-text"><?php echo $message; ?></span> <span class="progress-number"><b><?php echo e($cow_score->health_score); ?> </b>/100</span>
            <div class="progress sm">
              <div class="progress-bar progress-bar-<?php echo $color; ?>" style="width: <?php echo e($cow_score->health_score); ?>%"></div>
            </div>
          </div></td>
      </tr>
      <?php endif; ?>
    </table>
  </div>
</div>
</div>
<?php if(!empty($vaccine_pending)): ?>
<div class="row">
  <div class="col-md-12 ajax-page-bb" align="center">
    <h3 class="pending-vaccine-heading-color"><?php echo e(__('cow_monitor.five_pending_vaccine')); ?></h3>
  </div>
</div>
<div class="row ajax-page-pt15">
  <div class="col-md-12">
    <div class="col-md-12">
      <div>
        <table class="table table-bordered table-striped table-responsive">
          <thead>
            <tr>
              <th><?php echo e(__('cow_monitor.vaccine_name')); ?></th>
              <th><?php echo e(__('cow_monitor.time_days')); ?></th>
              <th class="th-center"><?php echo e(__('cow_monitor.repeat')); ?></th>
              <th><?php echo e(__('cow_monitor.dose')); ?></th>
              <th><?php echo e(__('cow_monitor.note')); ?></th>
            </tr>
          </thead>
          <tbody>
          
          <?php $__currentLoopData = $vaccine_pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pvl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($pvl->vaccine_name); ?></td>
            <td><?php echo e($pvl->months); ?></td>
            <td align="center"><?php if((bool)$pvl->repeat_vaccine): ?><i class="fa fa-check"></i><?php else: ?><i class="fa fa-close"></i><?php endif; ?></td>
            <td><?php echo e($pvl->dose); ?></td>
            <td><?php echo e($pvl->note); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>


<?php if(!empty($monitors)): ?>
<div class="row">
  <div class="col-md-12 ajax-page-bb" align="center">
    <h3 class="pending-vaccine-heading-color"><?php echo e(__('cow_monitor.last_five_monitoring')); ?></h3>
  </div>
</div>
<?php $__currentLoopData = $monitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row ajax-page-pt15">
  <div class="panel panel-default">
    <div class="panel-body">
      <div class="col-md-12">
        <div class="ajax-page-top-heading"><?php echo e(__('cow_monitor.monitoring_date')); ?> : <?php echo e(Carbon\Carbon::parse($m['date'])->format('M d, Y')); ?></div>
        <table class="table table-bordered table-striped table-responsive">
          <thead>
            <tr>
              <th><?php echo e(__('cow_monitor.weight')); ?></th>
              <th><?php echo e(__('cow_monitor.height')); ?></th>
              <th><?php echo e(__('cow_monitor.milk')); ?></th>
              <th><?php echo e(__('cow_monitor.reports')); ?></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><?php echo e($m['weight']); ?></td>
              <td><?php echo e($m['height']); ?></td>
              <td><?php echo e($m['milk']); ?></td>
              <td><?php echo e($m['note']); ?></td>
            </tr>
          </tbody>
        </table>
        <?php if(!empty($m['list'])): ?>
        <table class="table table-bordered table-striped table-responsive">
          <thead>
            <tr>
              <th><?php echo e(__('cow_monitor.service_name')); ?></th>
              <th><?php echo e(__('cow_monitor.result')); ?></th>
              <th><?php echo e(__('cow_monitor.monitoring_time')); ?></th>
            </tr>
          </thead>
          <tbody>
          
          <?php $__currentLoopData = $m['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($l->service_name); ?></td>
            <td><?php echo e($l->result); ?></td>
            <td><?php echo e($l->time); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          
        </table>
        <?php endif; ?>
        <div class="col-md-6 col-sm-12">
          <?php
						$color = '';
						$message = '';
						$hc = $m['health_score'];
						if((int)$hc >= 80){
							$color = 'green';
							$message = __('cow_monitor.good_condition');
						} else if((int)$hc < 80 && (int)$hc > 50){
							$color = 'yellow';
							$message = __('cow_monitor.warning_condition');
						} else if((int)$hc <= 50){
							$color = 'red';
							$message = __('cow_monitor.danger_condition');
						}
					?>
          <div class="progress-group"> <span class="progress-text"><?php echo $message; ?></span> <span class="progress-number"><b><?php echo e($hc); ?> </b>/100</span>
            <div class="progress sm">
              <div class="progress-bar progress-bar-<?php echo $color; ?>" style="width: <?php echo e($hc); ?>%"></div>
            </div>
          </div>
        </div>
        <div class="col-md-12" align="right"><b><?php echo e(__('cow_monitor.reported_by')); ?> <?php echo e($m['name']); ?></b> (<?php echo e($m['user_type']); ?>)</div>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/vflhvhga/hadirinn/resources/views/cow-monitor/ajax-animal.blade.php ENDPATH**/ ?>