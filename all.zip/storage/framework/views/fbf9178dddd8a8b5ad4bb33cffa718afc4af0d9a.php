
<?php $__env->startSection('title', __('salarylist.salary_title')); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="icon-people"></i> <?php echo e(__('salarylist.salary_title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
    <li class="active"> <?php echo e(__('salarylist.salary_title')); ?></li>
  </ol>
</section>
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('common.commonFunction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <?php if( !empty($employeeSalary) ): ?>
      <?php echo e(Form::open(array('route'=>['employee-salary.update',$employeeSalary->id],'method'=>'PUT','files'=>true))); ?>

      <button type="submit" class="btn btn-success btn-sm"><i class="fa fa-floppy-o"></i> <b><?php echo e(__('salarylist.update_information')); ?></b></button>
      <?php $display = 'block'; ?>
      <?php else: ?>
      <?php echo Form::open(array('route' => 'employee-salary.store','class'=>'form-horizontal','method' =>'POST','files'=>true)); ?>

      <button type="submit" class="btn btn-success btn-sm" id="submit"><i class="fa fa-floppy-o"></i> <b><?php echo e(__('salarylist.save_information')); ?></b></button>
      <?php $display = 'none'; ?>
      <?php endif; ?>
      &nbsp;&nbsp;<a href="<?php echo e(url('employee-salary')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-align-justify"></i> <b><?php echo e(__('salarylist.view_list')); ?></b></a> </div>
    <div class="box-body">
      <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-default">
          <div class="panel-heading"><i class="icon-list"></i> <?php echo e(__('salarylist.salary_info')); ?></div>
          <div class="panel-body">
            <div class="form-group">
              <label for="paydate"><?php echo e(__('salarylist.pay_date')); ?> <span class="validate">*</span> :</label>
              <input type="text" name="paydate" id="paydate" value="<?php echo e(isset($employeeSalary->paydate)?date('m/d/Y', strtotime($employeeSalary->paydate)):old('paydate')); ?>" class="form-control wsit_datepicker" placeholder="MM/DD/YYYY" required>
            </div>
            <div class="form-group">
              <label for="years"><?php echo e(__('salarylist.select_month')); ?> <span class="validate">*</span> :</label>
              <select class="form-control" name="month" id="years" required>
                <option value=""><?php echo e(__('same.select')); ?></option>
              	<?php if(isset($employeeSalary)): ?> 
                	<?php $__currentLoopData = months(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<option value="<?php echo e($key); ?>" <?php echo e(($employeeSalary->month==$key) ? 'selected':''); ?>><?php echo e($months); ?></option>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              	<?php else: ?>
                	<?php $__currentLoopData = months(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<option value="<?php echo e($key); ?>"><?php echo e($months); ?></option>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              	<?php endif; ?>
              </select>
            </div>
            <div class="form-group">
              <label for="years"><?php echo e(__('salarylist.select_year')); ?> <span class="validate">*</span> :</label>
              <select class="form-control" name="year" id="years" required>
                <option value=""><?php echo e(__('same.select')); ?></option>
                  <?php if(isset($employeeSalary)): ?>
                      <?php $__currentLoopData = years(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<option value="<?php echo e($year); ?>" <?php echo e(($employeeSalary->year==$year) ? 'selected':''); ?>><?php echo e($year); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                      <?php $__currentLoopData = years(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
              </select>
            </div>
            <div class="form-group">
              <label for="employeeList"><?php echo e(__('salarylist.select_employee')); ?> <span class="validate">*</span> :</label>
              <select class="form-control" name="employee_id" id="employeeList" required>
                <option value=""><?php echo e(__('same.select')); ?></option>
                  <?php if(!empty($employeeSalary)): ?>
                    <?php $__currentLoopData = $allEmployee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<option value="<?php echo e($employee->id); ?>" <?php echo e(($employeeSalary->employee_id==$employee->id) ? 'selected':''); ?> data-salary="<?php echo e($employee->gross_salary); ?>"><?php echo e($employee->name); ?> ( ID #<?php echo e($employee->id); ?> )</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  	<?php $__currentLoopData = $allEmployee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<option value="<?php echo e($employee->id); ?>" data-salary="<?php echo e($employee->gross_salary); ?>"> <?php echo e($employee->name); ?> ( ID #<?php echo e($employee->id); ?> ) </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
              </select>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="salary"><?php echo e(__('salarylist.month_salary')); ?> :</label>
                  <input type="text" name="salary" id="salary" value="<?php echo e(isset($employeeSalary->salary)?$employeeSalary->salary:old('salary')); ?>" class="form-control decimal" placeholder="Salary" required readonly>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="addition_money"><?php echo e(__('salarylist.addition_money')); ?> :</label>
                  <input type="text" name="addition_money" id="addition_money" value="<?php echo e(isset($employeeSalary->addition_money)?$employeeSalary->addition_money:old('addition_money')); ?>" class="form-control decimal" placeholder="Addition Money">
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="note"><?php echo e(__('salarylist.note')); ?> :</label>
              <textarea name="note" class="form-control"><?php echo e(isset($employeeSalary->note)?$employeeSalary->note:old('note')); ?></textarea>
            </div>
          </div>
        </div>
      </div>
      <?php echo Form::close(); ?> </div>
  </div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vflhvhga/hadirinn/resources/views/employee-salary/employee-salary.blade.php ENDPATH**/ ?>