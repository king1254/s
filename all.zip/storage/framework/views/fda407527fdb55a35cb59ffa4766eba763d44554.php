
<?php $__env->startSection('title', __('reports.vaccine_monitor_report') ); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="fa fa-area-chart"></i> <?php echo e(__('reports.vaccine_monitor_report')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('sale.home')); ?></a></li>
    <li class="active"><a><?php echo e(__('reports.vaccine_monitor_report')); ?></a></li>
  </ol>
</section>
<?php
$configuration_data = \App\Library\farm::get_system_configuration('system_config');
$branch_info =  \App\Library\farm::branchInfo();
?>
<!-- Main content -->
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('common.commonFunction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="box box-success">
    <div class="box-body">
      <div class="form-group"> <?php echo Form::open(array('url' => 'get-vaccine-monitor-report','class'=>'form-horizontal','autocomplete'=>'off','method' =>'GET')); ?>

        <div class="col-md-12">
          <div class="panel panel-default mt20">
            <div class="panel-heading"><i class="fa fa-search"></i> <?php echo e(__('reports.search_fields')); ?></div>
            <div class="panel-body pb250">
              <div class="col-md-3">
                <select class="form-control" name="shed_no">
                  <option value="0"><?php echo e(__('reports.select_a_stall')); ?></option>
                  <?php $__currentLoopData = $shedArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shedArrData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($shedArrData->id); ?>" <?php echo e(isset($shed_no)?($shed_no==$shedArrData->id)?'selected':'':''); ?>><?php echo e($shedArrData->shed_number); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-3">
                <input name="dairy_no" value="<?php echo e(isset($dairy_no)?$dairy_no:''); ?>" class="form-control" placeholder="<?php echo e(__('reports.animal_id')); ?>" type="text">
              </div>
              <?php if(isset($date_from)): ?>
              <div class="col-md-3">
                <input name="date_from" value="<?php echo e($date_from); ?>" id="date_from" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.start_date')); ?>" type="text" selected required>
              </div>
              <?php else: ?>
              <div class="col-md-3">
                <input name="date_from" value="" id="date_from" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.start_date')); ?>" type="text" selected required>
              </div>
              <?php endif; ?>
              <?php if(isset($date_to)): ?>
              <div class="col-md-3"> <?php if($date_to !=''): ?>
                <input name="date_to" value="<?php echo e($date_to); ?>" id="date_to" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.end_date')); ?>" type="text" selected required>
                <?php else: ?>
                <input name="date_to" value="" id="date_to" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.end_date')); ?>" type="text" selected required>
                <?php endif; ?> </div>
              <?php else: ?>
              <div class="col-md-3">
                <input name="date_to" value="" id="dateTo" class="form-control wsit_datepicker" placeholder="<?php echo e(__('same.end_date')); ?>" type="text" selected required>
              </div>
              <?php endif; ?>
              <div class="col-md-12"> <br>
                <button type="submit" class="btn btn-success btn100"><i class="fa fa-search"></i> <?php echo e(__('same.search')); ?></button>
              </div>
            </div>
          </div>
        </div>
        <?php echo Form::close(); ?>

        <div class="clearfix"></div>
      </div>
      <?php if(isset($hasData)): ?>
      <div class="table_scroll">
        <div id="print_icon"><a class="printReports" href="javascript:;"><img class="img-thumbnail" src='<?php echo e(asset("storage/app/public/common/print.png")); ?>'></a></div>
        <br>
        <br>
        <div id="printBox">
          <div id="printTable">
            <div class="col-md-12 print-base">
              <p><?php if(!empty($configuration_data) && !empty($configuration_data->logo)): ?><img src="<?php echo e(asset("storage/app/public/uploads/$configuration_data->logo")); ?>"/><?php endif; ?></p>
              <p class="print-ptag"><?php if(!empty($configuration_data) && !empty($configuration_data->topTitle)): ?><?php echo e($configuration_data->topTitle); ?><?php endif; ?></p>
              <?php if(!empty($branch_info->branch_name)) { ?>
              <p class="print-ptag"><?php echo e($branch_info->branch_name); ?></p>
              <?php } ?>
              <p class="print-ptag"><?php echo e(__('reports.vaccine_monitor_report')); ?></p>
              <p class="print-ptag"><?php echo e(__('reports.for_date')); ?> : <?php echo e($date_from); ?> 
                <?php if(isset($date_to)): ?>
                - <?php echo e($date_to); ?> 
                <?php endif; ?> </p>
            </div>
            <div class="table-div">
              <table class="table-print-style-1">
                <thead>
                  <tr>
                    <th rowspan="2"><?php echo e(__('same.sl')); ?></th>
                    <th rowspan="2"><?php echo e(__('same.date')); ?></th>
                    <th rowspan="2"><?php echo e(__('reports.animal_id')); ?></th>
                    <th rowspan="2"><?php echo e(__('reports.stall_no')); ?></th>
                    <th rowspan="2"><?php echo e(__('reports.note')); ?></th>
                    <th class="text-center" colspan="2"><?php echo e(__('reports.vaccine_details')); ?></th>
                  </tr>
                  <tr>
                    <th class="text-center width250"> <?php echo e(__('reports.vaccine_name')); ?> </th>
                    <th class="text-center width250"> <?php echo e(__('reports.remarks')); ?> </th>
                  </tr>
                </thead>
                <tbody>
                  <?php $sl = 0; ?>
                <?php if(isset($getJsonArr) && !empty($getJsonArr) && count($alldata)>0): ?>
                <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td> <?php echo e(++$sl); ?> </td>
                  <td> <?php echo e(date('m/d/Y', strtotime($data->date))); ?> </td>
                  <td> 000<?php echo e($data->cow_id); ?> </td>
                  <td> <?php echo e($data->shed_number); ?> </td>
                  <td> <?php echo e($data->note); ?> </td>
                  <td colspan="2"><?php  
                        $dtlsArr = DB::table('cow_vaccine_monitor_dtls')
                                  ->leftJoin('vaccines', 'vaccines.id','cow_vaccine_monitor_dtls.vaccine_id')
                                  ->where('cow_vaccine_monitor_dtls.monitor_id', $data->id)
                                  ->select('vaccines.vaccine_name', 'vaccines.months', 'cow_vaccine_monitor_dtls.*')
                                  ->get();
                      ?>
                    <table class="print-child-table">
                      <?php $__currentLoopData = $dtlsArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtlsArrData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="width250"> <?php echo e($dtlsArrData->vaccine_name); ?> - ( <?php echo e($dtlsArrData->months); ?> Months ) </td>
                        <td class="width250"> <?php echo e($dtlsArrData->remarks); ?> </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <tr>
                  <td colspan="7" align="center"><h2><?php echo e(__('same.empty_row')); ?></h2></td>
                </tr>
                <?php endif; ?>
                </tbody>
                
              </table>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?> </div>
  </div>
  <!-- /.box -->
</section>
<?php echo Html::style('public/custom/css/report.css'); ?>

<input type="hidden" id="print_url_1" value='<?php echo Html::style("public/custom/css/bootstrap.min.css"); ?>' />
<input type="hidden" id="print_url_2" value='<?php echo Html::style("public/custom/css/report.css"); ?>' />
<input type="hidden" id="print_url_3" value='<?php echo Html::style("public/custom/css/AdminLTE.css"); ?>' />
<!-- /.content -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vflhvhga/hadirinn/resources/views/reports/vaccine-monitor-report.blade.php ENDPATH**/ ?>