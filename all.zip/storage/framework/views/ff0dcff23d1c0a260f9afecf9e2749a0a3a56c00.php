<?php $__env->startSection('title', __('animal_pregnancy.title')); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1><i class="icon-symbol-female icons"></i> <?php echo e(__('animal_pregnancy.title')); ?></h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(__('same.home')); ?></a></li>
	<li class="active"><?php echo e(__('animal_pregnancy.title')); ?></li>
  </ol>
</section>
<section class="content">
  <!-- Default box -->
  <?php echo $__env->make('common.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('common.commonFunction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo e(Form::open(array('route' => 'animal-pregnancy.store', 'method' => 'post', 'onsubmit' => 'return submitDeliveryForm();', 'files' => true))); ?>

  <div class="box box-success">
    <div class="box-body">
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading feed-heading"><i class="icon-list"></i>&nbsp;<?php echo e(__('animal_pregnancy.animal_information')); ?> :</div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-12">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="stall_no"><?php echo e(__('animal_pregnancy.stall_no')); ?> <span class="validate">*</span> : </label>
                    <select class="form-control load-cow-pregnancy-page" name="stall_no" id="stall_no" data-url="<?php echo e(URL::to('load-cow')); ?>" required>
                      <option value=""><?php echo e(__('same.select')); ?></option>
						<?php $__currentLoopData = $all_sheds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sheds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      		<option value="<?php echo e($sheds->id); ?>" <?php echo e((!empty($single_data))?($sheds->id==$single_data->shed_no)?'selected':'':''); ?>><?php echo e($sheds->shed_number); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="cow_id"><?php echo e(__('animal_pregnancy.cow_no')); ?> <span class="validate">*</span> : </label>
                    <select class="form-control animal-details-by-stall-no" name="cow_id" id="cow_id" data-url="<?php echo e(URL::to('animal-pregnancy-monitor')); ?>" required>
                      <option value=""><?php echo e(__('same.select')); ?></option>
							<?php if(isset($single_data)): ?>
								<?php $__currentLoopData = $cowArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cowArrData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      				<option value="<?php echo e($cowArrData->id); ?>" <?php echo e(($cowArrData->id==$single_data->cow_id)?'selected':''); ?>>000<?php echo e($cowArrData->id); ?></option>
								 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
                    </select>
                  </div>
                </div>
                <div id="animal-details" align="center"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading feed-heading"><i class="icon-list"></i>&nbsp;<?php echo e(__('animal_pregnancy.animal_pregnancy_details')); ?> :</div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-12">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="pregnancy_type_id"><?php echo e(__('animal_pregnancy.pregnancy_type')); ?> <span class="validate">*</span> : </label>
                    <select class="form-control" name="pregnancy_type_id" id="pregnancy_type_id" required>
                      <option value=""><?php echo e(__('same.select')); ?></option>
						<?php $__currentLoopData = $pregnancy_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregnancy_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      		<option value="<?php echo e($pregnancy_type->id); ?>"><?php echo e($pregnancy_type->type_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="semen_type"><?php echo e(__('animal_pregnancy.semen_type')); ?> : </label>
                    <select class="form-control" name="semen_type" id="semen_type">
                      <option value="0"><?php echo e(__('same.select')); ?></option>
						<?php $__currentLoopData = $animal_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      		<option value="<?php echo e($animal_type->id); ?>"><?php echo e($animal_type->type_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="semen_push_date"><?php echo e(__('animal_pregnancy.semen_push_date')); ?> : </label>
                    <input type="text" name="semen_push_date" placeholder="<?php echo e(__('animal_pregnancy.mm_dd_YYYY')); ?>" class="form-control wsit_datepicker" value="">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="pregnancy_start_date"><?php echo e(__('animal_pregnancy.pregnancy_start_date')); ?> <span class="validate">*</span> : </label>
                    <input type="text" name="pregnancy_start_date" placeholder="<?php echo e(__('animal_pregnancy.mm_dd_YYYY')); ?>" class="form-control wsit_datepicker_calc_p_date" value="" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="semen_cost"><?php echo e(__('animal_pregnancy.semen_cost')); ?> : </label>
                    <input type="text" name="semen_cost" class="form-control" value="">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="other_cost"><?php echo e(__('animal_pregnancy.other_cost')); ?> : </label>
                    <input type="text" name="other_cost" class="form-control" value="">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="note"><?php echo e(__('animal_pregnancy.note')); ?> : </label>
                    <textarea class="form-control" id="note" name="note"></textarea>
                  </div>
                </div>
                <div class="col-md-12" id="appx-dd">
                  <div class="form-group">
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="appox-dd"><?php echo e(__('animal_pregnancy.axdd')); ?></div>
                        <div id="app-date-box"></div>
                        <div class="progress-group" id="appox-progress-box"> <span class="progress-text"><?php echo e(__('animal_pregnancy.approximate_delivery_progress')); ?></span> <span class="progress-number"><b>0 </b>/283</span>
                          <div class="progress sm">
                            <div id="appox-delivery-days" class="progress-bar progress-bar-green pbar-init"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-12" id="appx-dd">
                  <div class="form-group">
                    <div class="panel panel-default">
                      <div class="panel-body" align="right">
                        <button type="submit" class="btn btn-success"><i class="fa fa-floppy-o"></i> <b><?php echo e(__('animal_pregnancy.save_information')); ?></b></button>
                        <a href="<?php echo e(url('animal-pregnancy')); ?>" class="btn btn-warning"><i class="fa fa-refresh"></i> <b> <?php echo e(__('same.refresh')); ?></b></a> </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php echo Form::close(); ?> </section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\dairyfarm\resources\views/animal-pregnancy/index.blade.php ENDPATH**/ ?>